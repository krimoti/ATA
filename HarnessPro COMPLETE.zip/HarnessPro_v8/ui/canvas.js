'use strict';
/* UI: Canvas Engine */


// CANVAS ENGINE
// ============================================================
var CV, CTX;
var drag={active:false,type:"",id:"",ox:0,oy:0,ex:0,ey:0};
var selected=null;
var tool="select";
var wireStart=null;

function worldToScreen(wx,wy){return{x:wx*S.zoom+S.panX, y:wy*S.zoom+S.panY};}
function screenToWorld(sx,sy){return{x:(sx-S.panX)/S.zoom, y:(sy-S.panY)/S.zoom};}

function initCanvas(){
  CV=document.getElementById("main-canvas");
  CTX=CV.getContext("2d");
  resizeCanvas();
  window.addEventListener("resize",resizeCanvas);
  CV.addEventListener("mousedown",onMouseDown);
  CV.addEventListener("mousemove",onMouseMove);
  CV.addEventListener("mouseup",onMouseUp);
  CV.addEventListener("wheel",onWheel,{passive:false});
  CV.addEventListener("dblclick",onDblClick);
  CV.addEventListener("contextmenu",function(e){e.preventDefault();onRightClick(e);});
}

function resizeCanvas(){
  var wrap=document.getElementById("canvas-wrap");
  CV.width=wrap.clientWidth;
  CV.height=wrap.clientHeight;
  renderCanvas();
}

// ============================================================
// DRAW
// ============================================================
function renderCanvas(){
  if(!CV)return;
  CTX.clearRect(0,0,CV.width,CV.height);
  CTX.fillStyle="#0d0d0d"; CTX.fillRect(0,0,CV.width,CV.height);
  drawGrid();
  CTX.save();
  for(var i=0;i<S.dimensions.length;i++) drawDimension(S.dimensions[i]);
  for(var i=0;i<S.wires.length;i++) drawWire(S.wires[i]);
  if(wireStart){
    if(tool==="autoroute"){
      drawAutoRoutePreview({x:wireStart.wx,y:wireStart.wy},{x:drag.ex,y:drag.ey});
    } else {
      var ps=worldToScreen(wireStart.wx,wireStart.wy);
      CTX.strokeStyle="#d4b870"; CTX.lineWidth=1.5;
      CTX.setLineDash([4,3]);
      CTX.beginPath(); CTX.moveTo(ps.x,ps.y); CTX.lineTo(drag.ex,drag.ey); CTX.stroke();
      CTX.setLineDash([]);
    }
  }
  for(var i=0;i<S.elements.length;i++) drawElement(S.elements[i]);
  drawMultiHighlight();
  drawSelBox();
  CTX.restore();
}

function drawGrid(){
  var step=20*S.zoom, ox=S.panX%step, oy=S.panY%step;
  CTX.strokeStyle="rgba(255,255,255,0.04)"; CTX.lineWidth=0.5;
  for(var x=ox;x<CV.width;x+=step){CTX.beginPath();CTX.moveTo(x,0);CTX.lineTo(x,CV.height);CTX.stroke();}
  for(var y=oy;y<CV.height;y+=step){CTX.beginPath();CTX.moveTo(0,y);CTX.lineTo(CV.width,y);CTX.stroke();}
}

function drawElement(el){
  var s=worldToScreen(el.x,el.y);
  var z=S.zoom;
  var isSel=(selected&&selected.id===el.id);
  if(el.kind==="connector") drawConnector(el,s.x,s.y,z,isSel);
  else if(el.kind==="accessory") drawAccessory(el,s.x,s.y,z,isSel);
}

function getConnSize(el){
  var lib=CL[el.connId]; if(!lib) return{w:110,h:80};
  var FS=S.canvasFontSize||9;var rH=Math.max(16,FS*1.9);var hH=Math.max(24,FS*2.4);
  return{w:Math.max(110,FS*13)*S.zoom,h:(hH+lib.pins*rH+4)*S.zoom};
}

function drawConnector(el,sx,sy,z,isSel){
  var lib=CL[el.connId]; if(!lib) return;
  var pins=lib.pins;
  var FS=S.canvasFontSize||9;
  var rowH=Math.max(16,FS*1.9)*z;
  var hdrH=Math.max(24,FS*2.4)*z;
  var bw=Math.max(110,FS*13)*z;
  var bh=hdrH+pins*rowH+4*z;
  var isCustom=!lib.builtin;
  if(isSel){CTX.shadowColor=isCustom?"#5ab0f0":"#d4b870";CTX.shadowBlur=10;}
  CTX.fillStyle="#212121";
  CTX.strokeStyle=isSel?(isCustom?"#5ab0f0":"#d4b870"):(isCustom?"#1e4a80":"#4a4a4a");
  CTX.lineWidth=isSel?2:1;
  roundRect(CTX,sx,sy,bw,bh,5*z); CTX.fill(); CTX.stroke();
  CTX.shadowBlur=0;
  CTX.fillStyle=isCustom?"#0d2040":isSel?"#2a2000":"#181818";
  roundRect(CTX,sx,sy,bw,hdrH,5*z); CTX.fill();
  CTX.strokeStyle=isCustom?"#2a5a90":isSel?"#8a6010":"#383838";
  CTX.lineWidth=1;
  CTX.beginPath(); CTX.moveTo(sx,sy+hdrH); CTX.lineTo(sx+bw,sy+hdrH); CTX.stroke();
  CTX.fillStyle=isCustom?"#7acaf0":"#f0d060";
  CTX.font="bold "+Math.round(FS*z)+"px 'Courier New'";
  CTX.textAlign="center";
  CTX.fillText((el.label||"P?")+" - "+lib.short, sx+bw/2, sy+hdrH*0.66);
  var faceLeft=(el.side!=="right");
  for(var i=0;i<lib.pinout.length;i++){
    var p=lib.pinout[i];
    var py=sy+hdrH+i*rowH;
    CTX.fillStyle=i%2===0?"#1e1e1e":"#1a1a1a";
    CTX.fillRect(sx+1,py,bw-2,rowH-0.5);
    var dotX=faceLeft?sx:sx+bw, dotY=py+rowH/2;
    CTX.beginPath(); CTX.arc(dotX,dotY,Math.max(3.5,4.5*z),0,Math.PI*2);
    CTX.fillStyle=sc(p.c); CTX.fill();
    CTX.strokeStyle="rgba(0,0,0,0.7)"; CTX.lineWidth=0.8; CTX.stroke();
    CTX.fillStyle="#d4d4d4";
    CTX.font=Math.round(FS*0.95*z)+"px 'Courier New'";
    CTX.textAlign=faceLeft?"left":"right";
    CTX.fillText(p.id+" "+p.n, faceLeft?sx+10*z:sx+bw-10*z, py+rowH/2+FS*z*0.38);
    if(p.g){
      CTX.fillStyle="#505050";
      CTX.font=Math.round(FS*0.72*z)+"px 'Courier New'";
      CTX.textAlign=faceLeft?"right":"left";
      CTX.fillText(p.g, faceLeft?sx+bw-4*z:sx+4*z, py+rowH/2+FS*z*0.38);
    }
  }
  CTX.fillStyle="#686868";
  CTX.font=Math.round(FS*0.82*z)+"px 'Courier New'";
  CTX.textAlign="center";
  CTX.fillText(lib.name, sx+bw/2, sy+bh+Math.max(11,FS*1.3)*z);
}

function drawAccessory(el,sx,sy,z,isSel){
  var acc=null;
  for(var i=0;i<ACCESSORIES.length;i++){if(ACCESSORIES[i].id===el.accId){acc=ACCESSORIES[i];break;}}
  if(!acc) return;
  var w=50*z, h=28*z;
  CTX.fillStyle=acc.color||"#333";
  CTX.strokeStyle=isSel?"#d4b870":"#666";
  CTX.lineWidth=isSel?1.5:0.8;
  if(acc.type==="heatshrink"||acc.type==="sleeve"){
    CTX.beginPath();
    CTX.ellipse(sx,sy+h/2,6*z,h/2,0,Math.PI/2,Math.PI*3/2); CTX.stroke();
    CTX.fillRect(sx,sy,w,h); CTX.strokeRect(sx,sy,w,h);
    CTX.strokeStyle=isSel?"#d4b870":"#888";
    CTX.beginPath();
    CTX.ellipse(sx+w,sy+h/2,6*z,h/2,0,Math.PI/2*3,Math.PI/2); CTX.stroke();
  } else {
    roundRect(CTX,sx,sy,w,h,3*z); CTX.fill(); CTX.stroke();
  }
  CTX.fillStyle=acc.type==="heatshrink"?"#ccc":"#d4b870";
  CTX.font="bold "+(7*z)+"px 'Courier New'"; CTX.textAlign="center";
  CTX.fillText(acc.symbol, sx+w/2, sy+h/2+2.5*z);
  CTX.fillStyle="#888"; CTX.font=(6*z)+"px 'Courier New'";
  CTX.fillText(el.label||acc.name.split(" ").slice(0,2).join(" "), sx+w/2, sy+h+11*z);
}

// ============================================================
// AUTO-ROUTING ENGINE
// ============================================================

// Returns bounding box for an element in world coords (with margin)
function getElBounds(el, margin){
  margin=margin||0;
  var bw=90, bh=30;
  if(el.kind==="connector"){
    var lib=CL[el.connId]; if(lib) bh=Math.max(60,(lib.pins*14+30));
  } else {bw=50;bh=28;}
  return{x:el.x-margin,y:el.y-margin,w:bw+margin*2,h:bh+margin*2};
}

// Check if segment (x1,y1)-(x2,y2) intersects rect {x,y,w,h}
function segIntersectsRect(x1,y1,x2,y2,r){
  // Separating-axis: reject if segment is fully outside any axis
  var minX=Math.min(x1,x2),maxX=Math.max(x1,x2);
  var minY=Math.min(y1,y2),maxY=Math.max(y1,y2);
  if(maxX<r.x||minX>r.x+r.w||maxY<r.y||minY>r.y+r.h) return false;
  return true;
}

// Build an orthogonal route (world coords) from p1→p2
// avoids connector bodies (skip fromEl and toEl)
function buildOrthoRoute(p1,p2,fromElId,toElId){
  var GAP=18; // clearance around connectors
  var obstacles=[];
  S.elements.forEach(function(el){
    if(el.id===fromElId||el.id===toElId) return;
    if(el.kind==="connector") obstacles.push(getElBounds(el,GAP));
  });

  // Determine exit direction from p1 (pins face left/right)
  var fromEl=null,toEl=null;
  S.elements.forEach(function(e){if(e.id===fromElId)fromEl=e;if(e.id===toElId)toEl=e;});
  var exitRight= fromEl?(fromEl.side==="right"):false;
  var enterRight= toEl?(toEl.side!=="right"):true; // enter from pin side

  var exitX= exitRight? p1.x+GAP : p1.x-GAP;
  var enterX= enterRight? p2.x+GAP : p2.x-GAP;

  // 3-segment L-route: exit → mid column → enter
  var midX=(exitX+enterX)/2;
  var pts=[p1,{x:exitX,y:p1.y},{x:midX,y:p1.y},{x:midX,y:p2.y},{x:enterX,y:p2.y},p2];

  // Check if any obstacle blocks the mid-column segment
  var blocked=false;
  for(var i=0;i<obstacles.length;i++){
    var o=obstacles[i];
    if(segIntersectsRect(midX,p1.y,midX,p2.y,o)){blocked=true;break;}
  }
  if(blocked){
    // Route above all connectors
    var topY=p1.y, btmY=p2.y;
    S.elements.forEach(function(el){
      var b=getElBounds(el,GAP+10);
      if(midX>=b.x&&midX<=b.x+b.w) topY=Math.min(topY,b.y-GAP);
    });
    pts=[p1,{x:exitX,y:p1.y},{x:exitX,y:topY},{x:enterX,y:topY},{x:enterX,y:p2.y},p2];
  }
  return pts;
}

// Draw a multi-segment polyline with rounded corners
function drawPolylineRounded(pts, radius){
  if(!pts||pts.length<2) return;
  radius=radius||8;
  CTX.beginPath();
  CTX.moveTo(pts[0].x, pts[0].y);
  for(var i=1;i<pts.length-1;i++){
    var prev=pts[i-1], cur=pts[i], next=pts[i+1];
    var dx1=cur.x-prev.x, dy1=cur.y-prev.y;
    var dx2=next.x-cur.x, dy2=next.y-cur.y;
    var len1=Math.sqrt(dx1*dx1+dy1*dy1);
    var len2=Math.sqrt(dx2*dx2+dy2*dy2);
    if(len1<0.1||len2<0.1){CTX.lineTo(cur.x,cur.y);continue;}
    var r=Math.min(radius,len1/2,len2/2);
    var ux1=dx1/len1, uy1=dy1/len1;
    var ux2=dx2/len2, uy2=dy2/len2;
    CTX.lineTo(cur.x-ux1*r, cur.y-uy1*r);
    CTX.quadraticCurveTo(cur.x,cur.y, cur.x+ux2*r, cur.y+uy2*r);
  }
  CTX.lineTo(pts[pts.length-1].x, pts[pts.length-1].y);
  CTX.stroke();
}

function drawWire(w){
  var p1=null,p2=null;
  for(var i=0;i<S.elements.length;i++){
    var el=S.elements[i];
    if(el.id===w.fromEl){var pp=getPinPos(el,w.fromPin);if(pp)p1=pp;}
    if(el.id===w.toEl){var pp=getPinPos(el,w.toPin);if(pp)p2=pp;}
  }
  if(!p1&&w.x1!==undefined) p1={x:w.x1,y:w.y1};
  if(!p2&&w.x2!==undefined) p2={x:w.x2,y:w.y2};
  if(!p1||!p2) return;

  var style=w.routeStyle||getRouteStyle();
  var col=sc(w.color||"#888");
  CTX.strokeStyle=col; CTX.lineWidth=(1.5*S.zoom); CTX.setLineDash([]);

  if(style==="direct"){
    // Simple bezier (original)
    var s1=worldToScreen(p1.x,p1.y), s2=worldToScreen(p2.x,p2.y);
    var mx=(s1.x+s2.x)/2;
    CTX.beginPath(); CTX.moveTo(s1.x,s1.y);
    CTX.bezierCurveTo(mx,s1.y,mx,s2.y,s2.x,s2.y); CTX.stroke();
    drawWireLabel(w,s1,s2);
  } else if(style==="curve"){
    // Smooth curve through ortho waypoints
    var pts=w.routePts||(w.fromEl&&w.toEl?buildOrthoRoute(p1,p2,w.fromEl,w.toEl):null);
    if(!pts){
      var s1=worldToScreen(p1.x,p1.y), s2=worldToScreen(p2.x,p2.y);
      var mx=(s1.x+s2.x)/2;
      CTX.beginPath(); CTX.moveTo(s1.x,s1.y);
      CTX.bezierCurveTo(mx,s1.y,mx,s2.y,s2.x,s2.y); CTX.stroke();
      drawWireLabel(w,s1,s2); return;
    }
    var spts=pts.map(function(p){return worldToScreen(p.x,p.y);});
    drawPolylineRounded(spts, 12*S.zoom);
    drawWireLabel(w,spts[0],spts[spts.length-1]);
  } else {
    // ORTHO (default) — sharp corners
    var pts=w.routePts||(w.fromEl&&w.toEl?buildOrthoRoute(p1,p2,w.fromEl,w.toEl):null);
    if(!pts){
      var s1=worldToScreen(p1.x,p1.y), s2=worldToScreen(p2.x,p2.y);
      var mx=(s1.x+s2.x)/2;
      CTX.beginPath(); CTX.moveTo(s1.x,s1.y);
      CTX.bezierCurveTo(mx,s1.y,mx,s2.y,s2.x,s2.y); CTX.stroke();
      drawWireLabel(w,s1,s2); return;
    }
    var spts=pts.map(function(p){return worldToScreen(p.x,p.y);});
    drawPolylineRounded(spts, 5*S.zoom);
    drawWireLabel(w,spts[0],spts[spts.length-1]);
  }
}

function getRouteStyle(){
  var sel=document.getElementById("route-style");
  return sel?sel.value:"ortho";
}

function drawWireLabel(w,s1,s2){
  if(!showWireLabels) return;
  if(!w.signal&&!w.gauge) return;
  var lx=(s1.x+s2.x)/2, ly=(s1.y+s2.y)/2-6*S.zoom;
  var txt=(w.signal||"")+(w.gauge?" "+w.gauge:"");
  CTX.fillStyle="rgba(0,0,0,0.65)";
  var tw=CTX.measureText(txt).width+6;
  CTX.fillRect(lx-tw/2,ly-8*S.zoom,tw,10*S.zoom);
  CTX.fillStyle="#bbb"; CTX.font=(6*S.zoom)+"px 'Courier New'"; CTX.textAlign="center";
  CTX.fillText(txt,lx,ly);
}

// Draw preview line for wire-in-progress (auto-route mode)
function drawAutoRoutePreview(p1world, screenEnd){
  var style=getRouteStyle();
  CTX.strokeStyle="#5ab0f0"; CTX.lineWidth=1.5; CTX.setLineDash([4,3]);
  if(style==="direct"){
    var ps=worldToScreen(p1world.x,p1world.y);
    CTX.beginPath(); CTX.moveTo(ps.x,ps.y); CTX.lineTo(screenEnd.x,screenEnd.y); CTX.stroke();
  } else {
    var p2world=screenToWorld(screenEnd.x,screenEnd.y);
    var pts=buildOrthoRoute(p1world,p2world,wireStart.el?wireStart.el.id:null,null);
    var spts=pts.map(function(p){return worldToScreen(p.x,p.y);});
    drawPolylineRounded(spts, style==="curve"?12*S.zoom:5*S.zoom);
  }
  CTX.setLineDash([]);
}

// ── AUTO-ROUTE ALL ──
// Connects every pin of el1 to matching pin (by name/signal/index) of el2
function autoRouteAll(){
  var connEls=S.elements.filter(function(e){return e.kind==="connector";});
  if(connEls.length<2){toast("Need at least 2 connectors on canvas");return;}

  var style=getRouteStyle();

  // If exactly 2, use them; otherwise pick first two
  var el1=connEls[0], el2=connEls[1];
  var lib1=CL[el1.connId], lib2=CL[el2.connId];
  if(!lib1||!lib2){toast("Connector library missing");return;}

  var added=0, skipped=0;

  // Build lookup: existing wire endpoints to avoid duplicates
  var wiredPins={};
  S.wires.forEach(function(w){
    if(w.fromEl) wiredPins[w.fromEl+"_"+w.fromPin]=true;
    if(w.toEl)   wiredPins[w.toEl+"_"+w.toPin]=true;
  });

  var n=Math.min(lib1.pinout.length, lib2.pinout.length);
  for(var i=0;i<n;i++){
    var pin1=lib1.pinout[i], pin2=lib2.pinout[i];
    var k1=el1.id+"_"+pin1.id, k2=el2.id+"_"+pin2.id;
    if(wiredPins[k1]||wiredPins[k2]){skipped++;continue;}

    var p1=getPinPos(el1,pin1.id), p2=getPinPos(el2,pin2.id);
    if(!p1||!p2){skipped++;continue;}

    var pts=buildOrthoRoute(p1,p2,el1.id,el2.id);
    var wire={
      id:uid(),
      fromEl:el1.id, fromPin:pin1.id,
      toEl:el2.id,   toPin:pin2.id,
      color:sc(pin1.c)||"#888888",
      gauge:pin1.g||"22AWG",
      signal:pin1.sig||"",
      active:true,
      routeStyle:style,
      routePts:pts
    };
    S.wires.push(wire);
    wiredPins[k1]=true; wiredPins[k2]=true;
    added++;
  }

  saveState(); renderAll();
  toast("Auto-routed "+added+" wire"+(added!==1?"s":"")+(skipped?" ("+skipped+" skipped)":""));
}

function drawDimension(d){
  if(!d.x1&&d.x1!==0) return;
  var s1=worldToScreen(d.x1,d.y1), s2=worldToScreen(d.x2,d.y2);
  var off=20*S.zoom;
  var oy=s1.y-off;
  CTX.strokeStyle="#5ab0f0"; CTX.fillStyle="#5ab0f0"; CTX.lineWidth=0.8*S.zoom;
  CTX.beginPath(); CTX.moveTo(s1.x,oy); CTX.lineTo(s2.x,oy); CTX.stroke();
  arrow(CTX,s2.x,oy,s1.x,oy,5*S.zoom);
  arrow(CTX,s1.x,oy,s2.x,oy,5*S.zoom);
  CTX.setLineDash([3,3]);
  CTX.beginPath(); CTX.moveTo(s1.x,s1.y); CTX.lineTo(s1.x,oy); CTX.stroke();
  CTX.beginPath(); CTX.moveTo(s2.x,s2.y); CTX.lineTo(s2.x,oy); CTX.stroke();
  CTX.setLineDash([]);
  var len=Math.round(Math.abs(d.x2-d.x1));
  var tol=d.tol||0;
  var txt=len+"mm"+(tol?" +/-"+tol:"");
  CTX.font="bold "+(9*S.zoom)+"px 'Courier New'"; CTX.textAlign="center";
  var mx=(s1.x+s2.x)/2;
  CTX.fillStyle="rgba(0,0,0,0.7)";
  var tw=CTX.measureText(txt).width+8;
  CTX.fillRect(mx-tw/2,oy-10*S.zoom,tw,11*S.zoom);
  CTX.fillStyle="#5ab0f0";
  CTX.fillText(txt,mx,oy-1*S.zoom);
  if(d.balloon){
    var bx=(s1.x+s2.x)/2, by=oy-20*S.zoom;
    CTX.beginPath(); CTX.arc(bx,by,10*S.zoom,0,Math.PI*2);
    CTX.fillStyle="rgba(0,60,120,0.7)"; CTX.fill();
    CTX.strokeStyle="#5ab0f0"; CTX.lineWidth=0.8; CTX.stroke();
    CTX.fillStyle="#5ab0f0"; CTX.font="bold "+(7*S.zoom)+"px 'Courier New'";
    CTX.textAlign="center"; CTX.fillText(d.balloon,bx,by+2.5*S.zoom);
  }
}

function getPinPos(el,pinId){
  var lib=CL[el.connId]; if(!lib) return null;
  var FS=S.canvasFontSize||9;
  var rowH=Math.max(16,FS*1.9);
  var hdrH=Math.max(24,FS*2.4);
  var bw=Math.max(110,FS*13);
  var faceLeft=(el.side!=="right");
  for(var i=0;i<lib.pinout.length;i++){
    if(String(lib.pinout[i].id)===String(pinId)){
      var py=el.y+hdrH+i*rowH+rowH/2;
      var px=faceLeft?el.x:el.x+bw;
      return{x:px,y:py};
    }
  }
  return null;
}

function arrow(ctx,fromX,fromY,toX,toY,size){
  var angle=Math.atan2(toY-fromY,toX-fromX);
  ctx.beginPath();
  ctx.moveTo(fromX,fromY);
  ctx.lineTo(fromX+size*Math.cos(angle-Math.PI*0.8),fromY+size*Math.sin(angle-Math.PI*0.8));
  ctx.moveTo(fromX,fromY);
  ctx.lineTo(fromX+size*Math.cos(angle+Math.PI*0.8),fromY+size*Math.sin(angle+Math.PI*0.8));
  ctx.stroke();
}

function roundRect(ctx,x,y,w,h,r){
  ctx.beginPath();
  ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.quadraticCurveTo(x+w,y,x+w,y+r);
  ctx.lineTo(x+w,y+h-r); ctx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
  ctx.lineTo(x+r,y+h); ctx.quadraticCurveTo(x,y+h,x,y+h-r);
  ctx.lineTo(x,y+r); ctx.quadraticCurveTo(x,y,x+r,y); ctx.closePath();
}

// ============================================================
// MOUSE EVENTS
// ============================================================
function getElAt(wx,wy){
  for(var i=S.elements.length-1;i>=0;i--){
    var el=S.elements[i];
    var bw,bh;
    if(el.kind==="connector"){
      var lib=CL[el.connId]; if(!lib) continue;
      var FS2=S.canvasFontSize||9;bw=Math.max(110,FS2*13);bh=Math.max(24,FS2*2.4)+lib.pins*Math.max(16,FS2*1.9)+4;
    } else {bw=50;bh=28;}
    if(wx>=el.x&&wx<=el.x+bw&&wy>=el.y&&wy<=el.y+bh) return el;
  }
  return null;
}

function getPinAt(wx,wy){
  for(var i=0;i<S.elements.length;i++){
    var el=S.elements[i]; if(el.kind!=="connector") continue;
    var lib=CL[el.connId]; if(!lib) continue;
    var bh=Math.max(60,(lib.pins*14+30));
    var rowH=(bh-22)/lib.pins;
    var bw=90; var faceLeft=(el.side!=="right");
    for(var j=0;j<lib.pinout.length;j++){
      var py=el.y+22+j*rowH+rowH/2;
      var px=faceLeft?el.x:el.x+bw;
      var dx=wx-px,dy=wy-py;
      if(dx*dx+dy*dy<(8/S.zoom)*(8/S.zoom)){
        return{el:el,pin:lib.pinout[j],wx:px,wy:py};
      }
    }
  }
  return null;
}

var panning=false,panSX=0,panSY=0,panPX=0,panPY=0;


/* ============================================================
   CANVAS IMPROVEMENTS
   - Snap-to-grid with toggle
   - Multi-select (Shift+click, drag selection box)
   - Wire signal labels on canvas
   - Keyboard shortcuts (Delete, Escape, V/W/R/P/T)
   - Right-click context menu
   ============================================================ */

/* ── Snap to grid ── */
var SNAP_GRID = 20;
var snapEnabled = true;

function snapXY(x, y) {
  if (!snapEnabled) return {x:x, y:y};
  return {x: Math.round(x/SNAP_GRID)*SNAP_GRID, y: Math.round(y/SNAP_GRID)*SNAP_GRID};
}

function toggleSnap() {
  snapEnabled = !snapEnabled;
  var btn = document.getElementById('btn-snap');
  if (btn) {
    btn.style.background = snapEnabled ? 'var(--accent)' : 'var(--bg2)';
    btn.style.color      = snapEnabled ? '#000' : 'var(--text2)';
  }
  toast('Snap to grid: ' + (snapEnabled?'ON':'OFF'));
  renderCanvas();
}

/* ── Multi-select ── */
var multiSel = [];   /* array of element ids */
var selBox   = null; /* {x1,y1,x2,y2} drag selection */

function msToggle(elId) {
  var i = multiSel.indexOf(elId);
  if (i > -1) multiSel.splice(i, 1);
  else multiSel.push(elId);
}
function msClear() { multiSel = []; }
function msSelectAll() {
  multiSel = S.elements.map(function(e){return e.id;});
  renderCanvas();
  toast('Selected all: ' + multiSel.length);
}
function msDelete() {
  if (!multiSel.length) return;
  if (!confirm('Delete ' + multiSel.length + ' selected elements?')) return;
  pushUndo();
  var ids = multiSel.slice();
  S.elements = S.elements.filter(function(e){return ids.indexOf(e.id)<0;});
  S.wires    = S.wires.filter(function(w){return ids.indexOf(w.fromEl)<0 && ids.indexOf(w.toEl)<0;});
  msClear(); saveState(); renderAll();
  toast('Deleted ' + ids.length + ' elements');
}
function msMirror() {
  if (!multiSel.length) return;
  pushUndo();
  S.elements.forEach(function(el){
    if (multiSel.indexOf(el.id) > -1) el.side = (el.side==='right'?'left':'right');
  });
  saveState(); renderAll();
}
function msGroup(dx, dy) {
  /* Move all selected elements by delta */
  pushUndo();
  S.elements.forEach(function(el){
    if (multiSel.indexOf(el.id) > -1){ el.x+=dx; el.y+=dy; }
  });
  S.wires.forEach(function(w){
    if (w.fromEl && S.elements.findIndex && multiSel.indexOf(w.fromEl)>-1 && multiSel.indexOf(w.toEl)>-1) {
      /* both ends moving — keep routePts */
    }
  });
  saveState(); renderAll();
}

/* ── Draw selection box ── */
function drawSelBox() {
  if (!selBox) return;
  var s1 = worldToScreen(selBox.x1, selBox.y1);
  var s2 = worldToScreen(selBox.x2, selBox.y2);
  CTX.save();
  CTX.strokeStyle = 'rgba(100,180,255,0.8)';
  CTX.fillStyle   = 'rgba(100,180,255,0.08)';
  CTX.lineWidth   = 1;
  CTX.setLineDash([4,3]);
  CTX.beginPath();
  CTX.rect(s1.x, s1.y, s2.x-s1.x, s2.y-s1.y);
  CTX.fill(); CTX.stroke();
  CTX.setLineDash([]);
  CTX.restore();
}

/* ── Draw multi-select highlight ── */
function drawMultiHighlight() {
  if (!multiSel.length) return;
  multiSel.forEach(function(id){
    S.elements.forEach(function(el){
      if (el.id !== id) return;
      if (el.kind === 'connector') {
        var lib = CL[el.connId]; if (!lib) return;
        var FS = S.canvasFontSize||9;
        var bw = Math.max(110,FS*13)*S.zoom, bh = (Math.max(24,FS*2.4)+lib.pins*Math.max(16,FS*1.9)+4)*S.zoom;
        var s = worldToScreen(el.x, el.y);
        CTX.strokeStyle = 'rgba(100,180,255,0.8)';
        CTX.lineWidth = 2;
        CTX.setLineDash([5,3]);
        CTX.strokeRect(s.x-3, s.y-3, bw+6, bh+6);
        CTX.setLineDash([]);
      }
    });
  });
}

/* ── Wire label visibility toggle ── */
var showWireLabels = true;
function toggleWireLabels() {
  showWireLabels = !showWireLabels;
  var btn = document.getElementById('btn-wlabels');
  if (btn) btn.style.opacity = showWireLabels ? '1' : '0.4';
  renderCanvas();
}

/* ── Context menu ── */
function showContextMenu(wx, wy, sx, sy) {
  var existing = document.getElementById('ctx-menu');
  if (existing) existing.remove();

  var el = getElAt(wx, wy);
  var pin = getPinAt(wx, wy);

  var menu = document.createElement('div');
  menu.id = 'ctx-menu';
  menu.style.cssText = 'position:fixed;top:'+sy+'px;left:'+sx+'px;'
    +'background:#111;border:1px solid #3a3a3a;z-index:9990;min-width:160px;'
    +'box-shadow:0 4px 20px rgba(0,0,0,0.8);font-family:monospace;';

  function addItem(label, fn, sep) {
    if (sep) {
      var d = document.createElement('div');
      d.style.cssText = 'border-top:1px solid #2a2a2a;margin:2px 0';
      menu.appendChild(d);
    }
    var item = document.createElement('div');
    item.style.cssText = 'padding:7px 14px;cursor:pointer;font-size:9px;color:#c8c8c8;';
    item.onmouseover = function(){ this.style.background='#1e1e1e';this.style.color='#c8a840'; };
    item.onmouseout  = function(){ this.style.background='';this.style.color='#c8c8c8'; };
    item.textContent = label;
    item.onclick = function(){ menu.remove(); fn(); };
    menu.appendChild(item);
  }

  if (el) {
    addItem('Properties', function(){ showProps(el, el.kind); });
    addItem('Flip Side (L/R)', function(){ pushUndo(); el.side=(el.side==='right'?'left':'right'); saveState(); renderAll(); });
    if (multiSel.indexOf(el.id) < 0) {
      addItem('Add to Selection', function(){ msToggle(el.id); renderCanvas(); });
    } else {
      addItem('Remove from Selection', function(){ msToggle(el.id); renderCanvas(); });
    }
    addItem('Delete', function(){ deleteEl(el.id); }, true);
  } else {
    addItem('Select All (Ctrl+A)', function(){ msSelectAll(); });
    addItem('Paste (Ctrl+V)', function(){ toast('Use Ctrl+V after Ctrl+C'); });
    addItem('Fit View (F)', function(){ fitView(); });
    addItem('Toggle Snap ('+(snapEnabled?'ON':'OFF')+')', function(){ toggleSnap(); }, true);
  }

  if (multiSel.length > 1) {
    addItem('Delete Selected ('+multiSel.length+')', function(){ msDelete(); }, true);
    addItem('Mirror Selected', function(){ msMirror(); });
    addItem('Clear Selection', function(){ msClear(); renderCanvas(); });
  }

  document.body.appendChild(menu);

  /* Auto-remove on outside click */
  setTimeout(function(){
    document.addEventListener('click', function h(e){
      if (!menu.contains(e.target)){ menu.remove(); document.removeEventListener('click',h); }
    });
  }, 10);
}

function onMouseDown(e){
  var rect=CV.getBoundingClientRect();
  var sx=e.clientX-rect.left, sy=e.clientY-rect.top;
  var w=screenToWorld(sx,sy);
  if(e.button===1||(e.button===0&&tool==="pan")||(e.button===0&&e.altKey)){
    panning=true; panSX=sx; panSY=sy; panPX=S.panX; panPY=S.panY;
    CV.style.cursor="grabbing"; return;
  }
  if(tool==="wire"||tool==="autoroute"){
    var pin=getPinAt(w.x,w.y);
    if(!wireStart){
      if(pin){wireStart={el:pin.el,pin:pin.pin,wx:pin.wx,wy:pin.wy};}
      else{wireStart={wx:w.x,wy:w.y};}
      // Highlight chosen pin
      if(pin) updateRouteHint("Click destination pin to complete wire");
    } else {
      var isAuto=(tool==="autoroute");
      var style=getRouteStyle();
      var wire={id:uid(),color:"#888888",gauge:"22AWG",signal:"",active:true,routeStyle:isAuto?style:"direct"};
      if(wireStart.el){wire.fromEl=wireStart.el.id;wire.fromPin=wireStart.pin?wireStart.pin.id:null;
        // inherit pin color/gauge/signal
        if(wireStart.pin){wire.color=sc(wireStart.pin.c)||"#888888";wire.gauge=wireStart.pin.g||"22AWG";wire.signal=wireStart.pin.sig||"";}
      } else{wire.x1=wireStart.wx;wire.y1=wireStart.wy;}
      if(pin){wire.toEl=pin.el.id;wire.toPin=pin.pin.id;}
      else{wire.x2=w.x;wire.y2=w.y;}
      // Compute route for auto-route tool
      if(isAuto&&wire.fromEl&&wire.toEl){
        var p1=getPinPos({id:wire.fromEl,connId:getElConnId(wire.fromEl),x:0,y:0,side:"left"},wire.fromPin);
        // actually get from element
        var fe=null,te=null;
        S.elements.forEach(function(e){if(e.id===wire.fromEl)fe=e;if(e.id===wire.toEl)te=e;});
        if(fe&&te){
          var pp1=getPinPos(fe,wire.fromPin), pp2=getPinPos(te,wire.toPin);
          if(pp1&&pp2) wire.routePts=buildOrthoRoute(pp1,pp2,wire.fromEl,wire.toEl);
        }
      }
      S.wires.push(wire); wireStart=null;
      updateRouteHint(null);
      saveState(); renderCanvas(); showProps(wire,"wire"); return;
    }
    drag.ex=sx; drag.ey=sy; renderCanvas(); return;
  }
  if(tool==="dimension"){
    if(!wireStart){wireStart={wx:w.x,wy:w.y};}
    else{
      var dim={id:uid(),x1:wireStart.wx,y1:wireStart.wy,x2:w.x,y2:w.y,tol:20};
      S.dimensions.push(dim); wireStart=null;
      saveState(); renderCanvas(); showProps(dim,"dimension"); return;
    }
    drag.ex=sx; drag.ey=sy; renderCanvas(); return;
  }
  var el=getElAt(w.x,w.y);
  if(el){
    selected=el;
    drag.active=true; drag.id=el.id; drag.ox=w.x-el.x; drag.oy=w.y-el.y;
    if(e.shiftKey){msToggle(el.id);renderCanvas();return;}
    showProps(el, el.kind);
  } else {
    selected=null; clearProps();
  }
  renderCanvas();
}

function onMouseMove(e){
  var rect=CV.getBoundingClientRect();
  var sx=e.clientX-rect.left, sy=e.clientY-rect.top;
  var w=screenToWorld(sx,sy);
  if(panning){S.panX=panPX+(sx-panSX); S.panY=panPY+(sy-panSY); renderCanvas(); return;}
  drag.ex=sx; drag.ey=sy;
  if(drag.active){
    for(var i=0;i<S.elements.length;i++){
      if(S.elements[i].id===drag.id){S.elements[i].x=w.x-drag.ox; S.elements[i].y=w.y-drag.oy; break;}
    }
    // Recompute routePts for wires attached to moved element
    recomputeWireRoutes(drag.id);
    saveState(); renderCanvas();
  }
  if(wireStart) renderCanvas();
}

function onMouseUp(e){
  panning=false; drag.active=false; CV.style.cursor="default";
}

function onWheel(e){
  e.preventDefault();
  var rect=CV.getBoundingClientRect();
  var sx=e.clientX-rect.left, sy=e.clientY-rect.top;
  var factor=e.deltaY<0?1.1:0.9;
  var newZoom=clamp(S.zoom*factor,0.2,5);
  S.panX=sx-(sx-S.panX)*(newZoom/S.zoom);
  S.panY=sy-(sy-S.panY)*(newZoom/S.zoom);
  S.zoom=newZoom; renderCanvas();
}

function onDblClick(e){
  var rect=CV.getBoundingClientRect();
  var sx=e.clientX-rect.left,sy=e.clientY-rect.top;
  var w=screenToWorld(sx,sy);
  var el=getElAt(w.x,w.y);
  if(el) showProps(el,el.kind);
}

function onRightClick(e){
  e.preventDefault();
  var rect=CV.getBoundingClientRect();
  var sx=e.clientX-rect.left,sy=e.clientY-rect.top;
  var w=screenToWorld(sx,sy);
  showContextMenu(w.x,w.y,e.clientX,e.clientY);
}

// ============================================================
// PROPERTIES PANEL
// ============================================================
function showProps(obj,type){
  var p=document.getElementById("props");
  var h="<div style='font-size:9px;color:var(--accent);letter-spacing:2px;margin-bottom:6px'>PROPERTIES</div>";
  if(type==="connector"||type==="accessory"){
    h+="<div class='prop-row'><span class='prop-label'>LABEL</span><input class='fi' style='flex:1' value='"+esc(obj.label||"")+"' oninput=\"setProp('"+obj.id+"','label',this.value)\"/></div>";
    if(type==="connector"){
      h+="<div class='prop-row'><span class='prop-label'>SIDE</span><select class='fi' style='flex:1' onchange=\"setProp('"+obj.id+"','side',this.value)\">";
      h+="<option value='left'"+(obj.side!=="right"?" selected":"")+">Left (pins right)</option>";
      h+="<option value='right'"+(obj.side==="right"?" selected":"")+">Right (pins left)</option>";
      h+="</select></div>";
    }
    h+="<div class='prop-row'><span class='prop-label'>NOTES</span><input class='fi' style='flex:1' value='"+esc(obj.notes||"")+"' oninput=\"setProp('"+obj.id+"','notes',this.value)\"/></div>";
    h+="<div class='prop-row'><button class='btn' style='font-size:8px;padding:2px 6px' onclick=\"deleteEl('"+obj.id+"')\">DELETE</button></div>";
  } else if(type==="wire"){
    h+="<div class='prop-row'><span class='prop-label'>SIGNAL</span><input class='fi' style='flex:1' value='"+esc(obj.signal||"")+"' oninput=\"setWire('"+obj.id+"','signal',this.value)\"/></div>";
    h+="<div class='prop-row'><span class='prop-label'>GAUGE</span><select class='fi' style='flex:1' onchange=\"setWire('"+obj.id+"','gauge',this.value)\">";
    ["12AWG","14AWG","16AWG","18AWG","20AWG","22AWG","24AWG","26AWG","28AWG","30AWG"].forEach(function(g){h+="<option"+(obj.gauge===g?" selected":"")+">"+g+"</option>";});
    h+="</select></div>";
    h+="<div class='prop-row'><span class='prop-label'>COLOR</span><input type='color' value='"+(obj.color&&obj.color[0]==="#"?obj.color:"#888888")+"' style='width:40px;height:20px;border:none;cursor:pointer;background:none' oninput=\"setWire('"+obj.id+"','color',this.value)\"/></div>";
    h+="<div class='prop-row'><button class='btn' style='font-size:8px;padding:2px 6px' onclick=\"deleteWire('"+obj.id+"')\">DELETE</button></div>";
  } else if(type==="dimension"){
    h+="<div class='prop-row'><span class='prop-label'>TOL +/-</span><input type='number' class='fi' style='width:60px' value='"+(obj.tol||0)+"' oninput=\"setDim('"+obj.id+"','tol',+this.value)\"/></div>";
    h+="<div class='prop-row'><span class='prop-label'>BALLOON</span><input class='fi' style='flex:1' value='"+esc(obj.balloon||"")+"' placeholder='A,B...' oninput=\"setDim('"+obj.id+"','balloon',this.value)\"/></div>";
    h+="<div class='prop-row'><button class='btn' style='font-size:8px;padding:2px 6px' onclick=\"deleteDim('"+obj.id+"')\">DELETE</button></div>";
  }
  p.innerHTML=h;
}
function clearProps(){document.getElementById("props").innerHTML="<div style='font-size:9px;color:var(--text3);padding:4px'>Select an element</div>";}
function setProp(id,k,v){for(var i=0;i<S.elements.length;i++){if(S.elements[i].id===id){S.elements[i][k]=v;break;}}saveState();renderCanvas();}
function setWire(id,k,v){for(var i=0;i<S.wires.length;i++){if(S.wires[i].id===id){S.wires[i][k]=v;break;}}saveState();renderCanvas();}
function setDim(id,k,v){for(var i=0;i<S.dimensions.length;i++){if(S.dimensions[i].id===id){S.dimensions[i][k]=v;break;}}saveState();renderCanvas();}
function deleteEl(id){pushUndo();S.elements=S.elements.filter(function(e){return e.id!==id;});S.wires=S.wires.filter(function(w){return w.fromEl!==id&&w.toEl!==id;});selected=null;clearProps();saveState();renderCanvas();}
function deleteWire(id){S.wires=S.wires.filter(function(w){return w.id!==id;});clearProps();saveState();renderCanvas();}
function deleteDim(id){S.dimensions=S.dimensions.filter(function(d){return d.id!==id;});clearProps();saveState();renderCanvas();}

// ============================================================
// SIDEBAR
// ============================================================

var _sbFilter='', _sbTabActive='ALL';


/* ─── IEC 60757 Wire Color System ─── */
var IEC_COLORS = [
  {code:0, abbr:'BK', name:'Black',     hex:'#1a1a1a', textHex:'#fff'},
  {code:1, abbr:'BN', name:'Brown',     hex:'#7b3f00', textHex:'#fff'},
  {code:2, abbr:'RD', name:'Red',       hex:'#e74c3c', textHex:'#fff'},
  {code:3, abbr:'OG', name:'Orange',    hex:'#e67e22', textHex:'#fff'},
  {code:4, abbr:'YE', name:'Yellow',    hex:'#f1c40f', textHex:'#111'},
  {code:5, abbr:'GN', name:'Green',     hex:'#27ae60', textHex:'#fff'},
  {code:6, abbr:'BU', name:'Blue',      hex:'#2980b9', textHex:'#fff'},
  {code:7, abbr:'VT', name:'Violet',    hex:'#8e44ad', textHex:'#fff'},
  {code:8, abbr:'GY', name:'Grey',      hex:'#95a5a6', textHex:'#111'},
  {code:9, abbr:'WH', name:'White',     hex:'#e8e8e0', textHex:'#111'},
  {code:'PE',abbr:'GNYE',name:'Green/Yellow (Earth)',hex:'#27ae60',hex2:'#f1c40f',textHex:'#fff'}
];
var IEC_COMBOS = [
  {abbr:'BK/WH',c1:'#1a1a1a',c2:'#e8e8e0'},{abbr:'BK/RD',c1:'#1a1a1a',c2:'#e74c3c'},
  {abbr:'BK/BU',c1:'#1a1a1a',c2:'#2980b9'},{abbr:'RD/WH',c1:'#e74c3c',c2:'#e8e8e0'},
  {abbr:'RD/BK',c1:'#e74c3c',c2:'#1a1a1a'},{abbr:'WH/BK',c1:'#e8e8e0',c2:'#1a1a1a'},
  {abbr:'WH/RD',c1:'#e8e8e0',c2:'#e74c3c'},{abbr:'WH/BU',c1:'#e8e8e0',c2:'#2980b9'},
  {abbr:'BU/WH',c1:'#2980b9',c2:'#e8e8e0'},{abbr:'GN/YE',c1:'#27ae60',c2:'#f1c40f'},
  {abbr:'BN/WH',c1:'#7b3f00',c2:'#e8e8e0'},{abbr:'OG/WH',c1:'#e67e22',c2:'#e8e8e0'},
  {abbr:'GY/WH',c1:'#95a5a6',c2:'#e8e8e0'},{abbr:'YE/GN',c1:'#f1c40f',c2:'#27ae60'}
];

function iecGetAbbr(hex, hex2) {
  if (hex2) {
    for (var i=0;i<IEC_COMBOS.length;i++) if(IEC_COMBOS[i].c1===hex&&IEC_COMBOS[i].c2===hex2) return IEC_COMBOS[i].abbr;
    return 'CUST';
  }
  for (var j=0;j<IEC_COLORS.length;j++) if(IEC_COLORS[j].hex===hex) return IEC_COLORS[j].abbr;
  return 'CUST';
}

function iecColorSwatch(hex, hex2, size) {
  size = size || 14;
  if (!hex2)
    return '<span style="display:inline-block;width:'+size+'px;height:'+size+'px;'
      +'border-radius:2px;background:'+hex+';border:1px solid rgba(0,0,0,0.3);vertical-align:middle"></span>';
  return '<svg width="'+size+'" height="'+size+'" style="vertical-align:middle;border-radius:2px;'
    +'border:1px solid rgba(0,0,0,0.3)" viewBox="0 0 '+size+' '+size+'">'
    +'<rect width="'+size+'" height="'+size+'" fill="'+hex+'"/>'
    +'<polygon points="'+size+',0 '+size+','+size+' 0,'+size+'" fill="'+hex2+'"/></svg>';
}

/* ─── Wire number auto-assign ─── */
function wireAutoNumber() {
  var connEls = S.elements.filter(function(e){return e.kind==='connector';});
  S.wires.forEach(function(w, idx) {
    if (w.wireNum) return;  /* already has number */
    /* Format: page-connector-index e.g. 1-P1-001 */
    var fromLabel = '';
    connEls.forEach(function(e){if(e.id===w.fromEl) fromLabel=e.label||'?';});
    w.wireNum = '1-' + fromLabel + '-' + String(idx+1).padStart(3,'0');
  });
  saveState(); renderRoutes(); renderCanvas();
  toast('Wire numbers assigned');
}

/* ─── LVS: check unconnected pins + wire issues ─── */
function runLVS() {
  var errors = [], warnings = [];
  var connEls = S.elements.filter(function(e){return e.kind==='connector';});

  connEls.forEach(function(el) {
    var lib = CL[el.connId]; if (!lib) return;
    lib.pinout.forEach(function(pp) {
      var connected = false;
      S.wires.forEach(function(w) {
        if ((w.fromEl===el.id && String(w.fromPin)===String(pp.id)) ||
            (w.toEl===el.id   && String(w.toPin)  ===String(pp.id))) connected = true;
      });
      if (!connected && pp.sig !== 'NC' && pp.n !== 'NC')
        warnings.push('Unconnected: ' + (el.label||el.id) + ' pin ' + pp.id + ' (' + pp.n + ')');
    });
  });

  S.wires.forEach(function(w) {
    if (!w.fromEl || !w.toEl) errors.push('Floating wire (no connector): ' + w.id);
    if (w.fromEl && w.fromEl === w.toEl) errors.push('Self-loop: ' + (w.signal||w.id));
    /* AWG check vs pin spec */
    if (w.gauge && w.fromEl) {
      var el = null; S.elements.forEach(function(e){if(e.id===w.fromEl)el=e;});
      if (el) {
        var lib = CL[el.connId];
        if (lib) {
          lib.pinout.forEach(function(pp) {
            if (String(pp.id)===String(w.fromPin) && pp.g) {
              var specN = parseInt(pp.g), wireN = parseInt(w.gauge);
              if (!isNaN(specN) && !isNaN(wireN) && wireN > specN + 2)
                warnings.push('AWG mismatch: ' + (el.label||'?') + '.'+pp.id+' spec='+pp.g+' wire='+w.gauge);
            }
          });
        }
      }
    }
  });

  var panel = document.getElementById('lvs-panel');
  if (!panel) return;
  if (!errors.length && !warnings.length) {
    panel.innerHTML = '<div style="color:#27ae60;padding:4px 8px;font-size:9px;font-weight:bold">OK  No LVS errors</div>';
    return;
  }
  var h = '';
  errors.forEach(function(e2) {
    h += '<div style="color:#e74c3c;padding:2px 8px;font-size:8px">ERROR: '+esc(e2)+'</div>';
  });
  warnings.forEach(function(w2) {
    h += '<div style="color:#f39c12;padding:2px 8px;font-size:8px">WARN: '+esc(w2)+'</div>';
  });
  panel.innerHTML = h;
}

/* Color picker modal for wire */
var _cpWireId = null;
function openColorPicker(wireId) {
  _cpWireId = wireId;
  var w = null; S.wires.forEach(function(x){if(x.id===wireId)w=x;});
  if (!w) return;

  var m = document.getElementById('color-picker-modal');
  if (!m) {
    m = document.createElement('div');
    m.id = 'color-picker-modal';
    m.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:9999;display:flex;align-items:center;justify-content:center';
    m.onclick = function(e){if(e.target===m)m.remove();};
    document.body.appendChild(m);
  }

  var h = '<div style="background:#1a1a1a;border:1px solid #444;padding:0;min-width:480px;max-width:92vw">';
  h += '<div style="background:#111;padding:7px 12px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #333">';
  h += '<span style="font-size:9px;color:#c8a840;letter-spacing:2px;font-weight:bold">IEC 60757 WIRE COLOR</span>';
  h += '<button id="cp-close" style="background:none;border:none;color:#aaa;cursor:pointer;font-size:14px">x</button></div>';
  h += '<div style="padding:12px">';

  /* Base colors */
  h += '<div style="font-size:7px;color:#888;margin-bottom:5px;letter-spacing:1px">BASE COLORS (0-9 + PE)</div>';
  h += '<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:10px">';
  IEC_COLORS.forEach(function(c) {
    var active = (c.hex===w.color && !w.color2);
    h += '<div onclick="setWireColor(\''+c.hex+'\',null,\''+c.abbr+'\')" '
      +'style="cursor:pointer;padding:3px 7px;border:1.5px solid '+(active?'#c8a840':'#333')+';'
      +'background:#0a0a0a;display:flex;align-items:center;gap:5px;border-radius:2px" title="'+c.code+' '+c.name+'">'
      +iecColorSwatch(c.hex,null,13)
      +'<span style="font-size:8px;color:'+(active?'#c8a840':'#888')+'">'+c.code+' '+c.abbr+'</span></div>';
  });
  h += '</div>';

  /* Combinations */
  h += '<div style="font-size:7px;color:#888;margin-bottom:5px;letter-spacing:1px">COMBINATIONS</div>';
  h += '<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:10px">';
  IEC_COMBOS.forEach(function(c) {
    var active = (c.c1===w.color && c.c2===w.color2);
    h += '<div onclick="setWireColor(\''+c.c1+'\',\''+c.c2+'\',\''+c.abbr+'\')" '
      +'style="cursor:pointer;padding:3px 7px;border:1.5px solid '+(active?'#c8a840':'#333')+';'
      +'background:#0a0a0a;display:flex;align-items:center;gap:5px;border-radius:2px">'
      +iecColorSwatch(c.c1,c.c2,13)
      +'<span style="font-size:8px;color:'+(active?'#c8a840':'#888')+'">'+c.abbr+'</span></div>';
  });
  h += '</div>';

  /* Custom hex */
  h += '<div style="display:flex;align-items:center;gap:8px">'
    +'<span style="font-size:7px;color:#888">CUSTOM HEX:</span>'
    +'<input type="color" value="'+(w.color||'#888888')+'" id="cp-custom-hex" '
    +'style="width:36px;height:22px;border:none;padding:0;cursor:pointer;background:none">'
    +'<button onclick="setWireColor(document.getElementById(\'cp-custom-hex\').value,null,\'CUST\')" '
    +'style="background:#222;border:1px solid #444;color:#aaa;cursor:pointer;padding:2px 8px;font-size:8px">APPLY</button>'
    +'</div>';

  h += '</div></div>';
  m.innerHTML = h;
  document.getElementById('cp-close').onclick = function(){m.remove();};
}

function setWireColor(hex, hex2, abbr) {
  if (!_cpWireId) return;
  pushUndo();
  S.wires.forEach(function(w){
    if (w.id===_cpWireId){w.color=hex;w.color2=hex2||null;w.colorAbbr=abbr||'';}
  });
  saveState(); renderRoutes(); renderCanvas();
  var m = document.getElementById('color-picker-modal'); if(m) m.remove();
}

function buildSidebar(){
  var inner=document.getElementById('sidebar-inner');
  if(!inner)return;
  var FS=S.canvasFontSize||9;
  var h='';
  // Font size
  h+='<div style="padding:5px 8px;background:var(--bg0);border-bottom:1px solid var(--border);display:flex;align-items:center;gap:6px">';
  h+='<span style="font-size:7px;color:var(--text3);flex-shrink:0">TEXT</span>';
  h+='<input type="range" min="7" max="16" step="0.5" value="'+FS+'" id="fs-slider" style="flex:1;accent-color:var(--accent)">';
  h+='<span id="fs-val" style="font-size:9px;color:var(--accent);min-width:18px">'+FS+'</span>';
  h+='</div>';
  // Search
  h+='<div style="padding:5px 8px;border-bottom:1px solid var(--border)">';
  h+='<input id="sb-search" placeholder="Search connectors..." style="width:100%;background:var(--bg2);border:1px solid var(--border2);color:var(--text);padding:5px 8px;font-size:10px;font-family:monospace;box-sizing:border-box;outline:none">';
  h+='</div>';
  // Tabs
  h+='<div style="display:flex;border-bottom:1px solid var(--border)">';
  ['ALL','CONN','ACC','CUSTOM'].forEach(function(t){
    var on=(t==='ALL'&&_sbTabActive==='ALL')||(t===_sbTabActive);
    h+='<button data-sbtab="'+t+'" style="flex:1;padding:4px 2px;background:'+(on?'var(--accent)':'var(--bg1)')+';border:none;border-right:1px solid var(--border);color:'+(on?'#000':'var(--text3)')+';font-size:8px;font-family:monospace;cursor:pointer">'+t+'</button>';
  });
  h+='</div>';
  h+='<div id="sb-list" style="flex:1;overflow-y:auto;padding:6px"></div>';
  inner.innerHTML=h;

  // Events
  var search=document.getElementById('sb-search');
  if(search) search.oninput=function(){_sbFilter=this.value.toLowerCase();_sbRender();};
  var slider=document.getElementById('fs-slider');
  if(slider) slider.oninput=function(){
    S.canvasFontSize=+this.value;
    var fv=document.getElementById('fs-val'); if(fv)fv.textContent=this.value;
    saveState(); renderCanvas();
  };
  inner.addEventListener('click',function(e){
    var btn=e.target.closest('[data-sbtab]');
    if(!btn)return;
    _sbTabActive=btn.getAttribute('data-sbtab');
    inner.querySelectorAll('[data-sbtab]').forEach(function(b){
      var on2=b.getAttribute('data-sbtab')===_sbTabActive;
      b.style.background=on2?'var(--accent)':'var(--bg1)';
      b.style.color=on2?'#000':'var(--text3)';
    });
    _sbRender();
  });

  // Also attach drop to canvas-wrap
  var wrap=document.getElementById('canvas-wrap');
  if(wrap&&!wrap._dropReady){
    wrap._dropReady=true;
    wrap.addEventListener('dragover',function(e){e.preventDefault();});
    wrap.addEventListener('drop',function(e){
      e.preventDefault();
      var type=e.dataTransfer.getData('type'),itemId=e.dataTransfer.getData('itemId');
      var rect=CV.getBoundingClientRect();
      var w=screenToWorld(e.clientX-rect.left,e.clientY-rect.top);
      if(type==='conn') addConnector(itemId,w.x,w.y);
      else if(type==='acc') addAccessory(itemId,w.x,w.y);
    });
  }

  _sbRender();
}

function _sbRender(){
  var q=_sbFilter, t=_sbTabActive, h='';

  function card(c,isCustom){
    var dId=c.id;
    return '<div style="display:flex;flex-direction:column;align-items:center;padding:6px 4px;border:1px solid '+(isCustom?'#1a3050':'var(--border)')+';border-radius:3px;cursor:grab;text-align:center;background:var(--bg1);margin:0 0 4px 0;user-select:none" '
      +'draggable="true" ondragstart="sbDragStart(event,\'conn\',\''+dId+'\')" title="'+esc(c.name)+'">'
      +connMiniSVG(c)
      +'<div style="font-size:9px;font-weight:bold;color:'+(isCustom?'var(--accent3)':'var(--text)')+';margin-top:2px">'+esc(c.short)+'</div>'
      +'<div style="font-size:7px;color:var(--text3)">'+c.pins+'P</div>'
      +'</div>';
  }
  function accCard(a){
    return '<div style="display:flex;flex-direction:column;align-items:center;padding:5px 4px;border:1px solid var(--border);border-radius:3px;cursor:grab;text-align:center;background:var(--bg1);margin:0 0 4px 0;user-select:none" '
      +'draggable="true" ondragstart="sbDragStart(event,\'acc\',\''+a.id+'\')">'
      +'<span style="display:inline-block;width:18px;height:18px;border-radius:3px;background:'+(a.color||'#555')+';border:1px solid #666;margin-bottom:2px"></span>'
      +'<div style="font-size:9px;font-weight:bold;color:var(--text)">'+esc(a.symbol)+'</div>'
      +'<div style="font-size:7px;color:var(--text3)">'+esc(a.name.split(' ').slice(0,2).join(' '))+'</div>'
      +'</div>';
  }

  if(t==='ALL'||t==='CONN'){
    var cats={};
    for(var id in CL){
      if(!CL[id].builtin)continue;
      var c=CL[id];
      if(q&&c.short.toLowerCase().indexOf(q)<0&&c.name.toLowerCase().indexOf(q)<0&&(c.cat||'').toLowerCase().indexOf(q)<0)continue;
      if(!cats[c.cat])cats[c.cat]=[];
      cats[c.cat].push(c);
    }
    var keys=Object.keys(cats);
    if(keys.length){
      if(t==='ALL') h+='<div style="font-size:7px;color:var(--accent);letter-spacing:2px;margin:4px 0 5px;padding-bottom:3px;border-bottom:1px solid var(--border)">CONNECTORS</div>';
      keys.forEach(function(cat){
        h+='<div style="font-size:7px;color:var(--text3);letter-spacing:1px;margin:5px 0 3px">'+cat+'</div>';
        h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px">';
        cats[cat].forEach(function(c){h+=card(c,false);});
        h+='</div>';
      });
    }
  }

  if(t==='ALL'||t==='CUSTOM'){
    var customs=S.customConnectors.filter(function(c){
      return !q||c.short.toLowerCase().indexOf(q)>-1||c.name.toLowerCase().indexOf(q)>-1;
    });
    if(customs.length){
      h+='<div style="font-size:7px;color:var(--accent3);letter-spacing:2px;margin:8px 0 5px;padding-bottom:3px;border-bottom:1px solid #1a3a60">CUSTOM</div>';
      h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px">';
      customs.forEach(function(c){h+=card(c,true);});
      h+='</div>';
    }
  }

  if(t==='ALL'||t==='ACC'){
    var accs=ACCESSORIES.filter(function(a){return !q||a.name.toLowerCase().indexOf(q)>-1;});
    if(accs.length){
      h+='<div style="font-size:7px;color:var(--accent);letter-spacing:2px;margin:8px 0 5px;padding-bottom:3px;border-bottom:1px solid var(--border)">ACCESSORIES</div>';
      h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px">';
      accs.forEach(function(a){h+=accCard(a);});
      h+='</div>';
    }
  }

  if(!h) h='<div style="padding:20px;text-align:center;color:var(--text3);font-size:9px">No results</div>';
  var list=document.getElementById('sb-list');
  if(list)list.innerHTML=h;
}

function toggleSec(id){var el=document.getElementById(id);if(el)el.style.display=el.style.display==='none'?'':'none';}

function connMiniSVG(lib){
  var sz=18, t=lib.type||"RECT";
  if(t==="DSUB") return "<svg width='"+sz+"' height='"+sz+"' viewBox='0 0 18 18'><rect x='1' y='4' width='16' height='10' rx='2' fill='#3a3a3a' stroke='#666' stroke-width='0.8'/><circle cx='5' cy='9' r='2' fill='#d4b870'/><circle cx='9' cy='9' r='2' fill='#3498db'/><circle cx='13' cy='9' r='2' fill='#27ae60'/></svg>";
  if(t==="CIRC") return "<svg width='"+sz+"' height='"+sz+"' viewBox='0 0 18 18'><circle cx='9' cy='9' r='8' fill='#444' stroke='#666' stroke-width='0.8'/><circle cx='9' cy='9' r='5' fill='#2a2a2a'/><circle cx='9' cy='5' r='2' fill='#e74c3c'/><circle cx='13' cy='11' r='2' fill='#3498db'/><circle cx='5' cy='11' r='2' fill='#27ae60'/></svg>";
  if(t==="RJ")   return "<svg width='"+sz+"' height='"+sz+"' viewBox='0 0 18 18'><rect x='2' y='5' width='14' height='9' rx='2' fill='#c8c8c8' stroke='#888' stroke-width='0.8'/><rect x='4' y='8' width='2' height='5' fill='#e74c3c'/><rect x='7' y='8' width='2' height='5' fill='#27ae60'/><rect x='10' y='8' width='2' height='5' fill='#3498db'/><rect x='13' y='8' width='1' height='5' fill='#555'/></svg>";
  if(t==="USB")  return "<svg width='"+sz+"' height='"+sz+"' viewBox='0 0 18 18'><rect x='3' y='6' width='12' height='7' rx='2' fill='#888' stroke='#555' stroke-width='0.8'/><rect x='5' y='8' width='2' height='4' fill='#e74c3c'/><rect x='8' y='8' width='2' height='4' fill='#ccc'/><rect x='11' y='8' width='2' height='4' fill='#27ae60'/></svg>";
  // custom / RECT default — blue tint
  return "<svg width='"+sz+"' height='"+sz+"' viewBox='0 0 18 18'><rect x='2' y='4' width='14' height='10' rx='2' fill='#0a1e2e' stroke='#5ab0f0' stroke-width='0.8'/><circle cx='6' cy='9' r='2' fill='#5ab0f0'/><circle cx='9' cy='9' r='2' fill='#50d0a0'/><circle cx='12' cy='9' r='2' fill='#5ab0f0'/></svg>";
}

function sbDragStart(e,type,id){e.dataTransfer.setData("type",type);e.dataTransfer.setData("itemId",id);}
function toggleSec(id){var el=document.getElementById(id);if(el)el.style.display=el.style.display==="none"?"":"none";}

function addConnector(connId,wx,wy){pushUndo();
  var lib=CL[connId]; if(!lib) return;
  var label="P"+S.nextConnLabel++;
  S.elements.push({id:uid(),kind:"connector",connId:connId,label:label,x:wx,y:wy,side:"left",notes:""});
  saveState(); renderCanvas();
}
function addAccessory(accId,wx,wy){
  var acc=null; for(var i=0;i<ACCESSORIES.length;i++){if(ACCESSORIES[i].id===accId){acc=ACCESSORIES[i];break;}}
  if(!acc) return;
  S.elements.push({id:uid(),kind:"accessory",accId:accId,label:acc.name,x:wx,y:wy});
  saveState(); renderCanvas();
}

// ============================================================
// TOOLS
// ============================================================
function getElConnId(elId){
  for(var i=0;i<S.elements.length;i++){if(S.elements[i].id===elId) return S.elements[i].connId;}
  return null;
}

function updateRouteHint(msg){
  var el=document.getElementById("route-hint");
  if(!el) return;
  if(msg){el.textContent=msg; el.style.color="var(--accent)";}
  else{el.textContent="Drag from sidebar | Right-click=delete | Scroll=zoom | Alt+drag=pan"; el.style.color="var(--text3)";}
}

// Recompute ortho routePts for all wires touching a moved element
function recomputeWireRoutes(elId){
  S.wires.forEach(function(w){
    if(w.routeStyle&&w.routeStyle!=="direct"&&(w.fromEl===elId||w.toEl===elId)){
      var fe=null,te=null;
      S.elements.forEach(function(e){if(e.id===w.fromEl)fe=e;if(e.id===w.toEl)te=e;});
      if(fe&&te){
        var pp1=getPinPos(fe,w.fromPin), pp2=getPinPos(te,w.toPin);
        if(pp1&&pp2) w.routePts=buildOrthoRoute(pp1,pp2,w.fromEl,w.toEl);
      }
    }
  });
}

function setTool(t){
  tool=t; wireStart=null;
  document.querySelectorAll(".ctool").forEach(function(b){b.classList.remove("on");});
  var btn=document.getElementById("tool-"+t);
  if(btn) btn.classList.add("on");
  CV.style.cursor=(t==="wire"||t==="dimension"||t==="autoroute")?"crosshair":t==="pan"?"grab":"default";
  if(t==="autoroute"){
    updateRouteHint("⚡ Click a pin to start → click destination pin  |  ESC to cancel");
  } else {
    updateRouteHint(null);
  }
  renderCanvas();
}

function fitView(){
  if(!S.elements.length){S.zoom=1;S.panX=50;S.panY=50;renderCanvas();return;}
  var minX=99999,minY=99999,maxX=-99999,maxY=-99999;
  S.elements.forEach(function(el){
    minX=Math.min(minX,el.x); minY=Math.min(minY,el.y);
    maxX=Math.max(maxX,el.x+100); maxY=Math.max(maxY,el.y+200);
  });
  var pw=CV.width-80, ph=CV.height-80;
  var zx=pw/(maxX-minX+1), zy=ph/(maxY-minY+1);
  S.zoom=clamp(Math.min(zx,zy),0.2,2);
  S.panX=40-minX*S.zoom; S.panY=40-minY*S.zoom;
  renderCanvas();
}

// ============================================================
// CUSTOM CONNECTOR EDITOR (CCE)
// ============================================================
var CCE = {
  selectedId: null,   // id of connector currently being edited
  editBuf: null       // in-memory working copy while editing
};

// Default pin colors cycle
var PIN_COLORS = ["#e74c3c","#3498db","#27ae60","#f39c12","#9b59b6","#1abc9c","#e67e22","#c0392b",
                  "#2980b9","#16a085","#8e44ad","#d35400","#27ae60","#2c3e50","#7f8c8d","#f1c40f"];

function renderConnectorEditor(){
  var panel=document.getElementById("panel-connectors");

  // Build list of all connectors (built-in + custom)
  var allBuiltin=[], allCustom=[];
  for(var id in CL){
    if(CL[id].builtin) allBuiltin.push(CL[id]);
    else allCustom.push(CL[id]);
  }

  var listHTML='';

  // Custom connectors first
  if(allCustom.length){
    listHTML+='<div class="cat-label" style="padding:0 4px;margin-bottom:6px;color:#5ab0f0;font-size:7px;letter-spacing:1px">CUSTOM ('+allCustom.length+')</div>';
    allCustom.forEach(function(c){
      var active=(CCE.selectedId===c.id);
      listHTML+='<div class="cce-list-item custom-item'+(active?' active':'')+'" onclick="cceSelect(\''+c.id+'\',false)">';
      listHTML+='<div><div class="cce-item-name">'+esc(c.short)+'</div><div class="cce-item-meta">'+esc(c.name)+' &bull; '+c.pins+'p &bull; '+esc(c.cat)+'</div></div>';
      listHTML+='<span class="cce-item-badge badge-custom">CUSTOM</span>';
      listHTML+='</div>';
    });
  }

  // Built-in (read-only preview)
  listHTML+='<div class="cat-label" style="padding:0 4px;margin:8px 0 6px;color:var(--text3);font-size:7px;letter-spacing:1px">BUILT-IN ('+allBuiltin.length+')</div>';
  allBuiltin.forEach(function(c){
    var active=(CCE.selectedId===c.id);
    listHTML+='<div class="cce-list-item builtin'+(active?' active':'')+'" onclick="cceSelect(\''+c.id+'\',true)">';
    listHTML+='<div><div class="cce-item-name">'+esc(c.short)+'</div><div class="cce-item-meta">'+esc(c.name)+' &bull; '+c.pins+'p &bull; '+esc(c.cat)+'</div></div>';
    listHTML+='<span class="cce-item-badge badge-builtin">BUILT-IN</span>';
    listHTML+='</div>';
  });

  // Right pane: editor or placeholder
  var editorHTML='';
  if(!CCE.selectedId){
    editorHTML='<div style="flex:1;display:flex;flex-direction:column;justify-content:center;align-items:center;color:var(--text3);gap:12px">';
    editorHTML+='<div style="font-size:32px;opacity:0.2">&#9741;</div>';
    editorHTML+='<div style="font-size:9px;letter-spacing:2px">SELECT A CONNECTOR TO EDIT</div>';
    editorHTML+='<div style="font-size:8px;color:var(--text3)">or create a new one</div>';
    editorHTML+='</div>';
  } else {
    var isBuiltin=!!(CL[CCE.selectedId]&&CL[CCE.selectedId].builtin);
    if(isBuiltin){
      editorHTML=cceBuiltinPreview(CL[CCE.selectedId]);
    } else {
      editorHTML=cceEditorForm();
    }
  }

  panel.innerHTML='<div class="cce-layout" style="flex:1;height:100%">'
    +'<div class="cce-list-pane">'
    +'<div class="cce-list-header">'
    +'<span class="cce-list-title">LIBRARY</span>'
    +'<button class="btn btn-b" style="font-size:8px;padding:3px 8px" onclick="cceNew()">+ NEW</button>'
    +'</div>'
    +'<div class="cce-list-body">'+listHTML+'</div>'
    +'</div>'
    +'<div class="cce-editor-pane">'+editorHTML+'</div>'
    +'</div>';
}

function cceBuiltinPreview(lib){
  var h='<div class="cce-editor-header"><span class="cce-editor-title" style="color:var(--text2)">&#128274; '+esc(lib.name)+'</span>';
  h+='<button class="btn btn-b" style="font-size:8px;padding:3px 8px" onclick="cceDuplicate(\''+lib.id+'\')">DUPLICATE AS CUSTOM</button>';
  h+='</div>';
  h+='<div class="cce-editor-body">';
  h+='<div class="cce-readonly"><b>Built-in connector — read only.</b><br><br>';
  h+='Short: <b>'+esc(lib.short)+'</b> &nbsp; Type: <b>'+esc(lib.type)+'</b> &nbsp; Pins: <b>'+lib.pins+'</b> &nbsp; Cat: <b>'+esc(lib.cat)+'</b>';
  if(lib.pn) h+=' &nbsp; P/N: <b>'+esc(lib.pn)+'</b>';
  h+='<br><br>Click <b>DUPLICATE AS CUSTOM</b> to create an editable copy.</div>';
  // Pin table preview
  h+='<div style="margin-top:12px"><table class="pin-table"><thead><tr><th>#</th><th>PIN ID</th><th>NAME</th><th>SIGNAL</th><th>GAUGE</th><th>COLOR</th></tr></thead><tbody>';
  lib.pinout.forEach(function(p,i){
    h+='<tr><td style="text-align:center;color:var(--text3);font-size:8px">'+(i+1)+'</td>';
    h+='<td style="text-align:center;color:#5ab0f0;font-size:9px;font-weight:bold">'+esc(p.id)+'</td>';
    h+='<td style="font-size:9px">'+esc(p.n)+'</td>';
    h+='<td style="font-size:9px;color:var(--text2)">'+esc(p.sig)+'</td>';
    h+='<td style="font-size:9px;color:var(--text2)">'+esc(p.g)+'</td>';
    h+='<td><span style="display:inline-block;width:16px;height:16px;border-radius:50%;background:'+sc(p.c)+';border:1px solid #333;vertical-align:middle"></span></td></tr>';
  });
  h+='</tbody></table></div></div>';
  return h;
}

function cceEditorForm(){
  var buf=CCE.editBuf;
  if(!buf) return '';
  var isNew=!S.customConnectors.find(function(c){return c.id===buf.id;});

  var h='<div class="cce-editor-header">';
  h+='<span class="cce-editor-title">&#9741; '+(isNew?"NEW CONNECTOR":"EDIT: "+esc(buf.short))+'</span>';
  h+='<div style="display:flex;gap:6px">';
  if(!isNew) h+='<button class="btn btn-r" style="font-size:8px;padding:3px 8px" onclick="cceDelete(\''+buf.id+'\')">DELETE</button>';
  h+='<button class="btn" style="font-size:8px;padding:3px 8px" onclick="cceCancel()">CANCEL</button>';
  h+='<button class="btn btn-g" style="font-size:8px;padding:3px 8px" onclick="cceSave()">&#10003; SAVE</button>';
  h+='</div></div>';

  h+='<div class="cce-editor-body">';

  // Meta section
  h+='<div class="cce-section"><div class="cce-section-title">CONNECTOR INFO</div>';
  h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">';
  h+=cceField("NAME",   'cce-input hi',"cceSet('name',this.value)",esc(buf.name),"Full descriptive name");
  h+=cceField("SHORT",  'cce-input hi',"cceSet('short',this.value)",esc(buf.short),"Short code (e.g. DB9M)");
  h+=cceField("CAT",    'cce-input hi',"cceSet('cat',this.value)",esc(buf.cat),"Category");
  h+=cceField("P/N",    'cce-input hi',"cceSet('pn',this.value)",esc(buf.pn||""),"Part number (optional)");
  h+='</div>';
  // Type select
  h+='<div class="cce-row"><span class="cce-label">TYPE</span>';
  h+='<select class="cce-select" onchange="cceSet(\'type\',this.value)">';
  ["RECT","CIRC","DSUB","RJ","USB"].forEach(function(t){h+='<option'+(buf.type===t?" selected":"")+">"+t+"</option>";});
  h+='</select>';
  h+='<span style="font-size:8px;color:var(--text3);margin-left:8px">affects canvas icon style</span>';
  h+='</div>';
  h+='</div>';

  // Pin section
  h+='<div class="cce-section">';
  h+='<div class="cce-section-title" style="display:flex;justify-content:space-between;align-items:center">';
  h+='<span>PINS ('+buf.pinout.length+')</span>';
  h+='<div style="display:flex;gap:5px">';
  h+='<button class="btn btn-b" style="font-size:8px;padding:2px 8px" onclick="cceAddPin()">+ PIN</button>';
  h+='<button class="btn" style="font-size:8px;padding:2px 8px" onclick="cceAutoFill()">AUTO-FILL</button>';
  h+='</div></div>';

  h+='<table class="pin-table"><thead><tr>';
  h+='<th style="width:26px">#</th><th>PIN ID</th><th>NAME</th><th>SIGNAL</th><th>GAUGE</th><th>COLOR</th><th style="width:26px"></th>';
  h+='</tr></thead><tbody id="cce-pin-tbody">';
  buf.pinout.forEach(function(p,i){
    h+=ccePinRow(p,i);
  });
  h+='</tbody></table>';
  h+='</div>'; // end pins section

  // Live preview
  h+='<div class="cce-section"><div class="cce-section-title">PREVIEW</div>';
  h+='<div class="cce-preview">';
  h+=cceSVGPreview(buf);
  h+='</div></div>';

  h+='</div>'; // end body
  return h;
}

function cceField(label,cls,handler,val,ph){
  return '<div class="cce-row"><span class="cce-label">'+label+'</span><input class="'+cls+'" value="'+val+'" placeholder="'+esc(ph||"")+'" oninput="'+handler+'"/></div>';
}

function ccePinRow(p,i){
  var gauges=["12AWG","14AWG","16AWG","18AWG","20AWG","22AWG","24AWG","26AWG","28AWG","30AWG"];
  var sigs=["PWR","GND","DATA","SIG","RS232","ETH","USB","CAN","ANLG","AUD","HDMI","CLK","I2C","SPI","UART","NC"];
  var safeC=(p.c&&p.c[0]==="#")?p.c:(PIN_COLORS[i%PIN_COLORS.length]);
  var h='<tr id="cce-pin-'+i+'">';
  h+='<td><span class="pin-num">'+(i+1)+'</span></td>';
  // PIN ID
  h+='<td><input class="pi" style="width:52px" value="'+esc(p.id)+'" title="Pin ID" oninput="ccePinSet('+i+',\'id\',this.value)"/></td>';
  // NAME
  h+='<td><input class="pi" style="width:80px" value="'+esc(p.n)+'" title="Pin name" oninput="ccePinSet('+i+',\'n\',this.value)"/></td>';
  // SIGNAL
  h+='<td><select class="pi" style="width:72px" onchange="ccePinSet('+i+',\'sig\',this.value)">';
  sigs.forEach(function(s){h+='<option'+(p.sig===s?" selected":"")+">"+s+"</option>";});
  h+='</select></td>';
  // GAUGE
  h+='<td><select class="pi" style="width:68px" onchange="ccePinSet('+i+',\'g\',this.value)">';
  gauges.forEach(function(g){h+='<option'+(p.g===g?" selected":"")+">"+g+"</option>";});
  h+='</select></td>';
  // COLOR
  h+='<td><input type="color" class="pin-color-swatch" value="'+safeC+'" title="Pin color" onchange="ccePinSet('+i+',\'c\',this.value)"/></td>';
  // DELETE
  h+='<td><button class="del" title="Remove pin" onclick="cceRemovePin('+i+')">&#215;</button></td>';
  h+='</tr>';
  return h;
}

function cceSVGPreview(lib){
  // Render a small canvas-style SVG preview of the connector face
  var sz=120, pins=lib.pinout, po=pins, t=lib.type||"RECT";
  var cx=sz/2,cy=sz/2,R=sz*0.38;
  var s='<svg viewBox="0 0 '+sz+' '+sz+'" width="'+sz+'" height="'+sz+'" style="flex-shrink:0">';
  if(t==="CIRC"){
    s+='<circle cx="'+cx+'" cy="'+cy+'" r="'+(R+6)+'" fill="#555" stroke="#5ab0f0" stroke-width="1.5"/>';
    s+='<circle cx="'+cx+'" cy="'+cy+'" r="'+R+'" fill="#1a1a1a" stroke="#444" stroke-width="1"/>';
    for(var i=0;i<po.length;i++){
      var angle=(i/po.length)*Math.PI*2-Math.PI/2;
      var px=cx+R*0.72*Math.cos(angle),py=cy+R*0.72*Math.sin(angle);
      s+='<circle cx="'+px.toFixed(1)+'" cy="'+py.toFixed(1)+'" r="'+(sz*0.055)+'" fill="'+sc(po[i].c)+'" stroke="#222" stroke-width="0.5"/>';
    }
  } else if(t==="DSUB"){
    var rows=po.length<=9?[5,4]:po.length<=15?[8,7]:[Math.ceil(po.length/2),Math.floor(po.length/2)];
    var pw=sz*0.85,ph=sz*0.5,x0=(sz-pw)/2,y0=(sz-ph)/2+8;
    s+='<rect x="'+x0+'" y="'+y0+'" width="'+pw+'" height="'+ph+'" rx="8" fill="#2a2a2a" stroke="#5ab0f0" stroke-width="1"/>';
    var idx=0;
    for(var ri=0;ri<rows.length&&idx<po.length;ri++){
      var cnt=Math.min(rows[ri],po.length-idx);
      var rowY=y0+ph*0.28+ri*(ph*0.44),rowW=(cnt-1)*((pw-10)/(rows[0]));
      for(var pi=0;pi<cnt;pi++,idx++){
        var ppx=cx-rowW/2+pi*(rowW/(cnt-1||1));
        s+='<circle cx="'+ppx.toFixed(1)+'" cy="'+rowY.toFixed(1)+'" r="5" fill="'+sc(po[idx].c)+'" stroke="#111" stroke-width="0.5"/>';
      }
    }
  } else {
    // RECT / USB / RJ generic grid
    var cols=Math.ceil(Math.sqrt(po.length)),rows2=Math.ceil(po.length/cols);
    var pw=sz*0.8,ph=sz*0.7,x0=(sz-pw)/2,y0=(sz-ph)/2;
    s+='<rect x="'+x0+'" y="'+y0+'" width="'+pw+'" height="'+ph+'" rx="6" fill="#0a1e2e" stroke="#5ab0f0" stroke-width="1"/>';
    for(var i=0;i<po.length;i++){
      var ppx=x0+(i%cols+0.5)*(pw/cols), ppy=y0+(Math.floor(i/cols)+0.5)*(ph/rows2);
      var r=Math.min(pw/cols,ph/rows2)*0.28;
      s+='<circle cx="'+ppx.toFixed(1)+'" cy="'+ppy.toFixed(1)+'" r="'+r.toFixed(1)+'" fill="'+sc(po[i].c)+'" stroke="#111" stroke-width="0.5"/>';
    }
  }
  // Labels
  s+='<text x="'+cx+'" y="'+(sz-4)+'" text-anchor="middle" font-size="8" font-family="monospace" fill="#5ab0f0">'+esc(lib.short)+'</text>';
  s+='</svg>';

  // Also render a text legend
  var legend='<div style="margin-left:12px;overflow-y:auto;max-height:120px">';
  po.forEach(function(p){
    legend+='<div style="display:flex;align-items:center;gap:5px;font-size:8px;margin-bottom:2px">';
    legend+='<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:'+sc(p.c)+';border:1px solid #333;flex-shrink:0"></span>';
    legend+='<span style="color:#5ab0f0;min-width:22px">'+esc(p.id)+'</span>';
    legend+='<span style="color:var(--text2)">'+esc(p.n)+'</span>';
    legend+='<span style="color:var(--text3);margin-left:4px">'+esc(p.sig)+'</span>';
    legend+='</div>';
  });
  legend+='</div>';

  return '<div style="display:flex;align-items:flex-start">'+s+legend+'</div>';
}

// -- CCE Actions --

function cceNew(){
  var newId="CX"+Date.now().toString(36).toUpperCase();
  CCE.selectedId=newId;
  CCE.editBuf={
    id:newId, name:"Custom Connector", short:"CX1", type:"RECT",
    cat:"Custom", pn:"", pins:4, builtin:false,
    pinout:[
      {id:1,n:"VCC",sig:"PWR",g:"22AWG",c:"#e74c3c"},
      {id:2,n:"GND",sig:"GND",g:"22AWG",c:"#555555"},
      {id:3,n:"SIG1",sig:"DATA",g:"24AWG",c:"#3498db"},
      {id:4,n:"SIG2",sig:"DATA",g:"24AWG",c:"#27ae60"}
    ]
  };
  renderConnectorEditor();
}

function cceSelect(id,isBuiltin){
  CCE.selectedId=id;
  if(!isBuiltin){
    // Deep clone for editing
    var found=S.customConnectors.find(function(c){return c.id===id;});
    if(found) CCE.editBuf=JSON.parse(JSON.stringify(found));
  } else {
    CCE.editBuf=null;
  }
  renderConnectorEditor();
}

function cceSet(key,val){
  if(!CCE.editBuf) return;
  CCE.editBuf[key]=val;
  if(key==="short"||key==="type") cceRefreshPreview();
}

function ccePinSet(idx,key,val){
  if(!CCE.editBuf||!CCE.editBuf.pinout[idx]) return;
  CCE.editBuf.pinout[idx][key]=val;
  cceRefreshPreview();
}

function cceRefreshPreview(){
  // Update pin count
  if(CCE.editBuf) CCE.editBuf.pins=CCE.editBuf.pinout.length;
  // Refresh just the preview div if it exists
  var prev=document.querySelector('.cce-preview');
  if(prev) prev.innerHTML=cceSVGPreview(CCE.editBuf);
}

function cceAddPin(){
  if(!CCE.editBuf) return;
  var i=CCE.editBuf.pinout.length;
  CCE.editBuf.pinout.push({
    id:i+1, n:"P"+(i+1), sig:"SIG", g:"22AWG",
    c:PIN_COLORS[i%PIN_COLORS.length]
  });
  CCE.editBuf.pins=CCE.editBuf.pinout.length;
  // Append row instead of full re-render for performance
  var tbody=document.getElementById("cce-pin-tbody");
  if(tbody){
    var tr=document.createElement("tr");
    tr.id="cce-pin-"+i;
    tr.innerHTML=ccePinRow(CCE.editBuf.pinout[i],i).replace(/^<tr[^>]*>/,"").replace(/<\/tr>$/,"");
    tbody.appendChild(tr);
  }
  cceRefreshPreview();
}

function cceRemovePin(idx){
  if(!CCE.editBuf||CCE.editBuf.pinout.length<=1){toast("Connector must have at least 1 pin",true);return;}
  CCE.editBuf.pinout.splice(idx,1);
  CCE.editBuf.pins=CCE.editBuf.pinout.length;
  // Re-number remaining pinout IDs if they are numeric
  CCE.editBuf.pinout.forEach(function(p,i){if(!isNaN(p.id)) p.id=i+1;});
  renderConnectorEditor();
}

function cceAutoFill(){
  if(!CCE.editBuf) return;
  var n=parseInt(prompt("How many pins?",CCE.editBuf.pinout.length)||"0",10);
  if(!n||n<1||n>200){toast("Enter 1–200 pins",true);return;}
  var po=[];
  for(var i=0;i<n;i++) po.push({id:i+1,n:"P"+(i+1),sig:"SIG",g:"22AWG",c:PIN_COLORS[i%PIN_COLORS.length]});
  CCE.editBuf.pinout=po;
  CCE.editBuf.pins=n;
  renderConnectorEditor();
}

function cceSave(){
  if(!CCE.editBuf) return;
  var b=CCE.editBuf;
  // Validate
  if(!b.name.trim()){toast("Name is required",true);return;}
  if(!b.short.trim()){toast("Short code is required",true);return;}
  if(!b.pinout.length){toast("At least one pin required",true);return;}
  // Check short uniqueness (among custom only — builtins can't be overridden)
  var dup=S.customConnectors.find(function(c){return c.id!==b.id && c.short.toLowerCase()===b.short.toLowerCase();});
  if(dup){toast("Short code '"+b.short+"' already used by another custom connector",true);return;}

  b.pins=b.pinout.length;
  b.builtin=false;

  var existing=S.customConnectors.findIndex(function(c){return c.id===b.id;});
  if(existing>=0) S.customConnectors[existing]=JSON.parse(JSON.stringify(b));
  else S.customConnectors.push(JSON.parse(JSON.stringify(b)));

  syncCustomConnectors();
  CCE.selectedId=b.id;
  CCE.editBuf=JSON.parse(JSON.stringify(b));

  saveState();
  buildSidebar();
  renderConnectorEditor();
  toast("Connector '"+b.short+"' saved!");
}

function cceCancel(){
  // If it was a new unsaved connector, deselect
  var found=S.customConnectors.find(function(c){return c.id===CCE.selectedId;});
  if(!found){ CCE.selectedId=null; CCE.editBuf=null; }
  else {
    CCE.editBuf=JSON.parse(JSON.stringify(found));
  }
  renderConnectorEditor();
}

function cceDelete(id){
  if(!confirm("Delete custom connector? Any canvas instances will be removed.")) return;
  S.customConnectors=S.customConnectors.filter(function(c){return c.id!==id;});
  // Remove canvas elements using this connector
  S.elements=S.elements.filter(function(e){return e.connId!==id;});
  S.wires=S.wires.filter(function(w){
    var rem=S.elements.find(function(e){return e.id===w.fromEl||e.id===w.toEl;});
    return !!rem;
  });
  delete CL[id];
  CCE.selectedId=null; CCE.editBuf=null;
  saveState(); buildSidebar(); renderCanvas();
  renderConnectorEditor();
  toast("Connector deleted");
}

function cceDuplicate(builtinId){
  var src=CL[builtinId]; if(!src) return;
  var newId="CX"+Date.now().toString(36).toUpperCase();
  CCE.selectedId=newId;
  CCE.editBuf=JSON.parse(JSON.stringify(src));
  CCE.editBuf.id=newId;
  CCE.editBuf.builtin=false;
  CCE.editBuf.short=src.short+"_C";
  CCE.editBuf.name=src.name+" (Custom)";
  CCE.editBuf.cat="Custom";
  renderConnectorEditor();
  toast("Duplicated '"+src.short+"' — edit and save");
}

// ============================================================
// DRAWING PANEL (printable)
// ============================================================
function connFaceSVG(lib,sz){
  if(!lib)return"";
  var cx=sz/2,cy=sz/2,R=sz*0.38,pins=lib.pins,po=lib.pinout,t=lib.type,s="";
  s='<svg viewBox="0 0 '+sz+' '+sz+'" width="'+sz+'" height="'+sz+'">';
  if(t==="DSUB"){
    var rows=pins<=9?[5,4]:pins<=15?[8,7]:[13,12];
    var pw=sz*0.85,ph=sz*0.55,x0=(sz-pw)/2,y0=(sz-ph)/2;
    var pw2=Math.min(10,pw/(rows[0]+1)),ph2=pw2*1.6;
    s+='<rect x="'+x0+'" y="'+y0+'" width="'+pw+'" height="'+ph+'" rx="'+(sz*0.07)+'" fill="#3a3a3a" stroke="#666" stroke-width="1"/>';
    var idx=0;
    for(var ri=0;ri<rows.length;ri++){
      var cnt=rows[ri],rowY=y0+ph*0.28+ri*(ph*0.44),rowW=(cnt-1)*(pw2+3);
      for(var pi=0;pi<cnt&&idx<po.length;pi++,idx++){
        var px=cx-rowW/2+pi*(pw2+3);
        s+='<rect x="'+(px-pw2/2)+'" y="'+(rowY-ph2/2)+'" width="'+pw2+'" height="'+ph2+'" rx="1" fill="'+sc(po[idx].c)+'" stroke="#222" stroke-width="0.5"/>';
      }
    }
  } else if(t==="CIRC"){
    s+='<circle cx="'+cx+'" cy="'+cy+'" r="'+(R+6)+'" fill="#555" stroke="#888" stroke-width="1.5"/>';
    s+='<circle cx="'+cx+'" cy="'+cy+'" r="'+R+'" fill="#2a2a2a" stroke="#444" stroke-width="1"/>';
    for(var i=0;i<po.length;i++){
      var angle=(i/pins)*Math.PI*2-Math.PI/2;
      var px2=cx+R*0.72*Math.cos(angle),py2=cy+R*0.72*Math.sin(angle);
      s+='<circle cx="'+px2+'" cy="'+py2+'" r="'+(sz*0.055)+'" fill="'+sc(po[i].c)+'" stroke="#222" stroke-width="0.5"/>';
    }
  } else if(t==="RJ"){
    var pw=sz*0.65,ph=sz*0.5,x0=(sz-pw)/2,y0=(sz-ph)/2;
    s+='<rect x="'+x0+'" y="'+y0+'" width="'+pw+'" height="'+ph+'" rx="3" fill="#c8c8c8" stroke="#888" stroke-width="1"/>';
    for(var i=0;i<po.length;i++){var px=(x0+(i+0.5)/pins*pw);s+='<rect x="'+(px-4)+'" y="'+(y0+ph*0.3)+'" width="7" height="'+(ph*0.6)+'" rx="1" fill="'+sc(po[i].c)+'" stroke="#222" stroke-width="0.5"/>';}
  } else {
    var cols=Math.ceil(Math.sqrt(pins)),rows2=Math.ceil(pins/cols),pw=sz*0.75,ph=sz*0.65,x0=(sz-pw)/2,y0=(sz-ph)/2;
    s+='<rect x="'+x0+'" y="'+y0+'" width="'+pw+'" height="'+ph+'" rx="4" fill="#2a2a2a" stroke="#666" stroke-width="1"/>';
    for(var i=0;i<po.length;i++){var px=x0+(i%cols+0.5)*(pw/cols),py=y0+(Math.floor(i/cols)+0.5)*(ph/rows2),r3=Math.min(pw/cols,ph/rows2)*0.32;s+='<circle cx="'+px+'" cy="'+py+'" r="'+r3+'" fill="'+sc(po[i].c)+'" stroke="#222" stroke-width="0.5"/>';}
  }
  s+='</svg>'; return s;
}

function wireTableHTML(lib,side,wires){
  if(!lib)return"";
  var other=side==="L"?"P2":"P1";
  var h='<table><thead><tr><th class="dwg-th">PIN</th><th class="dwg-th">NAME</th><th class="dwg-th">SIG</th><th class="dwg-th">AWG</th><th class="dwg-th">COLOR</th><th class="dwg-th">'+esc(other)+'</th></tr></thead><tbody>';
  for(var i=0;i<lib.pinout.length;i++){
    var p=lib.pinout[i];
    var w2=null;
    for(var j=0;j<wires.length;j++){
      var w3=wires[j];
      var myEl=null;
      for(var k=0;k<S.elements.length;k++){
        if(S.elements[k].id===w3.fromEl&&side==="L"){myEl=S.elements[k];}
        if(S.elements[k].id===w3.toEl&&side==="R"){myEl=S.elements[k];}
      }
      if(myEl&&String(side==="L"?w3.fromPin:w3.toPin)===String(p.id)){w2=w3;break;}
    }
    var ow=w2?(side==="L"?w2.toPin:w2.fromPin):"--";
    h+='<tr style="background:'+(i%2?"#f5f2eb":"#faf8f4")+'">';
    h+='<td class="dwg-td" style="font-weight:bold;color:#336699;text-align:center">'+esc(p.id)+'</td>';
    h+='<td class="dwg-td">'+esc(p.n)+'</td>';
    h+='<td class="dwg-td">'+esc(w2?w2.signal||p.sig:p.sig)+'</td>';
    h+='<td class="dwg-td" style="text-align:center;color:#555">'+esc(p.g)+'</td>';
    h+='<td class="dwg-td" style="text-align:center"><span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:'+sc(p.c)+';border:1px solid #333"></span></td>';
    h+='<td class="dwg-td" style="text-align:center;font-weight:bold;color:#336699">'+esc(ow)+'</td></tr>';
  }
  return h+'</tbody></table>';
}

function xcrossSVG(wires){
  var active=wires.filter(function(w){return w.fromEl&&w.toEl;});
  if(!active.length) return '<p style="color:#888;font-size:9px">No wires defined</p>';
  var rowH=22,W=380,pad=12,H=active.length*rowH+pad*2+20;
  var c1=55,c2=130,c3=250,c4=325,mid=190;
  var s='<svg viewBox="0 0 '+W+' '+H+'" style="width:100%;display:block">';
  s+='<rect x="0" y="0" width="'+W+'" height="18" fill="#c8c4b4"/>';
  ["P1 PIN","WIRE","P2 PIN","SIGNAL"].forEach(function(t,i){var x=[c1,mid,c4,W-6][i],ta=i===3?"end":"middle";s+='<text x="'+x+'" y="12" text-anchor="'+ta+'" font-size="7.5" font-family="monospace" font-weight="bold" fill="#333">'+t+'</text>';});
  for(var i=0;i<active.length;i++){
    var w=active[i],y=18+pad+i*rowH,cy=y+rowH/2-3,col=sc(w.color);
    s+='<rect x="0" y="'+y+'" width="'+W+'" height="'+rowH+'" fill="'+(i%2?"#f5f3ee":"#faf8f5")+'"/>';
    s+='<circle cx="'+c1+'" cy="'+cy+'" r="9" fill="#dce8f4" stroke="#336699" stroke-width="1"/>';
    s+='<text x="'+c1+'" y="'+(cy+3.5)+'" text-anchor="middle" font-size="7.5" font-family="monospace" font-weight="bold" fill="#224466">'+esc(w.fromPin)+'</text>';
    s+='<line x1="'+(c1+9)+'" y1="'+cy+'" x2="'+c2+'" y2="'+cy+'" stroke="'+col+'" stroke-width="2.5"/>';
    s+='<line x1="'+c2+'" y1="'+(cy-6)+'" x2="'+c3+'" y2="'+(cy+6)+'" stroke="'+col+'" stroke-width="2"/>';
    s+='<line x1="'+c2+'" y1="'+(cy+6)+'" x2="'+c3+'" y2="'+(cy-6)+'" stroke="'+col+'" stroke-width="2"/>';
    s+='<line x1="'+c3+'" y1="'+cy+'" x2="'+(c4-9)+'" y2="'+cy+'" stroke="'+col+'" stroke-width="2.5"/>';
    s+='<rect x="'+(mid-18)+'" y="'+(cy-7)+'" width="36" height="13" fill="#f8f5ee" stroke="#ccc" stroke-width="0.5"/>';
    s+='<text x="'+mid+'" y="'+(cy+3)+'" text-anchor="middle" font-size="6.5" font-family="monospace" fill="#666">'+esc(w.gauge)+'</text>';
    s+='<circle cx="'+c4+'" cy="'+cy+'" r="9" fill="#dce8f4" stroke="#336699" stroke-width="1"/>';
    s+='<text x="'+c4+'" y="'+(cy+3.5)+'" text-anchor="middle" font-size="7.5" font-family="monospace" font-weight="bold" fill="#224466">'+esc(w.toPin)+'</text>';
    s+='<text x="'+(W-6)+'" y="'+(cy+3.5)+'" text-anchor="end" font-size="6.5" font-family="monospace" fill="#555">'+esc(w.signal)+'</text>';
  }
  return s+'</svg>';
}

function renderDrawing(){
  var connEls=S.elements.filter(function(e){return e.kind==="connector";});
  var B="1px solid #c8c4b4";
  var today=new Date().toLocaleDateString();
  var h='<div id="dwg-sheet">';
  h+='<div style="display:grid;grid-template-columns:1fr 130px 130px 55px;border-bottom:'+B+'">';
  h+='<div style="border-right:'+B+';padding:4px 8px"><div style="font-size:6px;color:#777;border-bottom:'+B+';margin-bottom:1px">TITLE</div><div style="font-size:16px;font-weight:bold">'+esc(S.title)+'</div></div>';
  h+='<div style="border-right:'+B+';padding:4px 6px"><div style="font-size:6px;color:#777;border-bottom:'+B+'">CUSTOMER</div><div style="font-size:9px;padding-top:2px">'+esc(S.company||"--")+'</div></div>';
  h+='<div style="border-right:'+B+';padding:4px 6px"><div style="font-size:6px;color:#777;border-bottom:'+B+'">PART NUMBER</div><div style="font-size:11px;font-weight:bold;padding-top:2px">'+esc(S.partNo||"--")+'</div></div>';
  h+='<div style="padding:4px 5px"><div style="font-size:6px;color:#777;border-bottom:'+B+'">REV.</div><div style="font-size:16px;font-weight:bold;padding-top:2px">'+esc(S.rev||"A")+'</div></div>';
  h+='</div>';
  h+='<div style="border-bottom:'+B+';padding:8px 10px;text-align:center;color:#888;font-size:9px">';
  h+='[ Cable schematic -- see Canvas tab for interactive drawing ]</div>';
  if(connEls.length){
    h+='<div style="border-bottom:'+B+';display:grid;grid-template-columns:repeat('+Math.min(connEls.length,3)+',1fr)">';
    for(var i=0;i<Math.min(connEls.length,6);i++){
      var el=connEls[i]; var lib=CL[el.connId];
      h+='<div style="'+(i%3!==2?"border-right:"+B+";":"")+';padding:6px 8px">';
      h+='<div style="font-size:8px;font-weight:bold;color:#336699;margin-bottom:4px">'+esc(el.label)+' - '+esc(lib?lib.short:"")+'</div>';
      if(lib){
        h+='<div style="display:flex;gap:8px;align-items:flex-start">';
        h+='<div style="flex-shrink:0">'+connFaceSVG(lib,70)+'<div style="font-size:6px;color:#666;text-align:center;margin-top:2px">'+esc(lib.name)+'</div></div>';
        h+='<div style="flex:1;overflow-x:auto">'+wireTableHTML(lib,i===0?"L":"R",S.wires)+'</div>';
        h+='</div>';
      }
      h+='</div>';
    }
    h+='</div>';
  }
  h+='<div style="display:grid;grid-template-columns:1fr 1fr;border-bottom:'+B+'">';
  h+='<div style="border-right:'+B+';padding:6px 10px"><div style="font-size:8px;font-weight:bold;color:#336699;margin-bottom:4px">WIRE DIAGRAM</div>'+xcrossSVG(S.wires)+'</div>';
  h+='<div style="padding:6px 10px"><div style="font-size:8px;font-weight:bold;color:#555;margin-bottom:4px">VARIANT / ACCESSORIES</div>';
  h+='<table><thead><tr><th class="dwg-th">QTY</th><th class="dwg-th">TYPE</th><th class="dwg-th">DESCRIPTION</th></tr></thead><tbody>';
  var accEls=S.elements.filter(function(e){return e.kind==="accessory";});
  accEls.forEach(function(el,i){
    var acc=null; for(var j=0;j<ACCESSORIES.length;j++){if(ACCESSORIES[j].id===el.accId){acc=ACCESSORIES[j];break;}}
    h+='<tr style="background:'+(i%2?"#f5f2eb":"#faf8f4")+'"><td class="dwg-td" style="text-align:center">1</td><td class="dwg-td">'+esc(acc?acc.type:"")+'</td><td class="dwg-td">'+esc(el.label)+'</td></tr>';
  });
  h+='</tbody></table></div></div>';
  h+='<div style="display:grid;grid-template-columns:1fr 190px">';
  h+='<div style="border-right:'+B+';padding:5px 8px"><div style="font-size:7px;font-weight:bold;color:#777;margin-bottom:3px;letter-spacing:1px">NOTES:</div>';
  h+='<ol style="padding-left:14px;font-size:7px;line-height:1.9;color:#333">';
  S.notes.forEach(function(n){h+='<li>'+esc(n)+'</li>';});
  h+='</ol></div>';
  h+='<div style="padding:5px 8px;font-size:8px"><table style="width:100%;margin-bottom:6px">';
  [["DWG NO.",S.dwgNo||"--"],["DATE",today],["DRAWN",S.drawnBy||"***"],["SCALE","1:1"],["SHEET","1 OF 1"]].forEach(function(r){
    h+='<tr><td style="font-weight:bold;color:#555;padding:1px 4px;font-size:7px;border-bottom:'+B+';white-space:nowrap">'+r[0]+'</td><td style="padding:1px 4px;font-size:7px;border-bottom:'+B+'">'+esc(r[1])+'</td></tr>';
  });
  h+='</table><div style="border:2px solid #27ae60;padding:3px 5px;font-size:7px;color:#27ae60;font-weight:bold;display:inline-block">RoHS<br>COMPLIANT</div></div></div>';
  h+='</div>';
  document.getElementById("panel-drawing").innerHTML='<div style="overflow:auto;flex:1;padding:8px">'+h+'</div>';
}

// ============================================================
// ROUTES PANEL
// ============================================================
/* ============================================================
   WIRE LIST — Production-grade panel
   Replaces renderRoutes()
   Every column the production floor needs.
   ============================================================ */