'use strict';
/* Service: Engineering Drawing */


var DWG_SCALE = 1;

/* ── Modal open/close ── */
function openDwgModal() {
  if (!H.nodes) H.nodes = [];
  if (!H.segs)  H.segs  = [];
  hvBuildTopology();
  document.getElementById('dwg-modal').style.display = 'flex';
  setTimeout(dwgRegen, 100);
}
function closeDwgModal() {
  document.getElementById('dwg-modal').style.display = 'none';
}

/* ── Zoom / Fit ── */
function dwgZoom(f) {
  DWG_SCALE = Math.max(0.2, Math.min(3, DWG_SCALE * f));
  _dwgApply();
}
function dwgFit() {
  var sc = document.getElementById('dwg-scroll');
  var pp = document.getElementById('dwg-paper');
  if (!sc || !pp) return;
  pp.style.transform = 'scale(1)';
  DWG_SCALE = Math.max(0.15, Math.min(1.3, (sc.clientWidth - 40) / (pp.offsetWidth || 1340)));
  _dwgApply();
}
function _dwgApply() {
  var p = document.getElementById('dwg-paper');
  if (p) { p.style.transform = 'scale(' + DWG_SCALE + ')'; p.style.transformOrigin = 'top left'; }
}

/* ── Regen ── */
function dwgRegen() {
  var wrap = document.getElementById('dwg-paper');
  if (!wrap) return;
  try {
    if (!H.nodes) H.nodes = [];
    if (!H.segs)  H.segs  = [];
    hvBuildTopology();
    var svg = buildDrawing({ S: S, CL: CL, H: H });
    wrap.innerHTML = svg;
    wrap.style.display = 'block';
    setTimeout(dwgFit, 80);
  } catch (err) {
    wrap.innerHTML = '<div style="padding:40px;font-family:monospace;color:#e74c3c;background:#111;font-size:11px">'
      + '<b>Drawing error:</b><br><br>' + String(err) + '</div>';
    console.error('dwgRegen:', err);
  }
}

/* ── Print ── */
function dwgPrint() {
  var wrap = document.getElementById('dwg-paper');
  if (!wrap) return;
  var win = window.open('', '_blank');
  if (!win) return;
  win.document.write('<!DOCTYPE html><html><head><meta charset="UTF-8">'
    + '<title>' + (S.title || 'Drawing') + '</title>'
    + '<style>@page{size:A3 landscape;margin:4mm}body{margin:0;padding:0;background:#fff}</style>'
    + '</head><body>' + wrap.innerHTML + '</body></html>');
  win.document.close();
  win.focus();
  setTimeout(function () { win.print(); }, 500);
}

/* ── Pan inside modal ── */
(function () {
  var el, drag = false, sx, sy, sl, st;
  function g() { el = document.getElementById('dwg-scroll'); }
  document.addEventListener('mousedown', function (e) {
    if (!el) g();
    if (!el || !el.contains(e.target)) return;
    if (e.target.tagName === 'BUTTON' || e.target.tagName === 'SELECT') return;
    drag = true; sx = e.clientX; sy = e.clientY; sl = el.scrollLeft; st = el.scrollTop;
    el.style.cursor = 'grabbing';
  });
  document.addEventListener('mousemove', function (e) {
    if (!drag) return;
    el.scrollLeft = sl - (e.clientX - sx);
    el.scrollTop  = st - (e.clientY - sy);
  });
  document.addEventListener('mouseup', function () {
    drag = false; if (el) el.style.cursor = 'grab';
  });
  document.addEventListener('wheel', function (e) {
    if (!el) g();
    if (!el || !el.contains(e.target)) return;
    if (e.ctrlKey || e.metaKey) { e.preventDefault(); dwgZoom(e.deltaY < 0 ? 1.1 : 0.91); }
  }, { passive: false });
})();

/* ============================================================
   SVG BUILDER
   A3 landscape: 1340 x 940 logical px
   ============================================================ */
function buildDrawing(data) {
  var S  = data.S  || {};
  var CL = data.CL || {};
  var H  = data.H  || { nodes: [], segs: [] };

  if (!S.elements)  S.elements  = [];
  if (!S.wires)     S.wires     = [];
  if (!S.bomItems)  S.bomItems  = [];
  if (!S.notes)     S.notes     = ['No open/short or intermittent failures.', '100% electrical test required.', 'All dimensions in mm unless noted.'];

  /* ── Paper dimensions ── */
  var PW = 1340, PH = 940;
  var ML = 25, MR = 25, MT = 20, MB = 20;
  var TB_H = 62;              /* title block height */
  var DX = ML, DY = MT;
  var DW = PW - ML - MR;
  var TB_Y = PH - MB - TB_H;
  var WORK_H = TB_Y - DY;     /* usable drawing height */

  /* ── Layout zones ── */
  var ECO_W = 200, ECO_H = 56;
  var HARNESS_H = Math.round(WORK_H * 0.50);  /* harness diagram */
  var PIN_Y  = DY + HARNESS_H + 4;
  var PIN_H  = WORK_H - HARNESS_H - 4;
  var BOM_W  = Math.round(DW * 0.36);
  var PIN_W  = DW - BOM_W - 4;

  /* ── SVG helpers ── */
  var out = [];
  function p(s) { out.push(s); }
  function xe(s) { return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function xc(c) { return (c && (c[0] === '#' || c.indexOf('hsl') === 0)) ? c : '#888'; }
  function f1(n) { return Number(n).toFixed(1); }

  /* ── SVG root ── */
  p('<svg xmlns="http://www.w3.org/2000/svg" width="' + PW + '" height="' + PH + '"'
    + ' viewBox="0 0 ' + PW + ' ' + PH + '"'
    + ' style="font-family:\'Courier New\',Courier,monospace;background:#fff;display:block">');

  /* Background */
  p('<rect width="' + PW + '" height="' + PH + '" fill="#f7f5ee"/>');

  /* Borders */
  p('<rect x="' + ML + '" y="' + MT + '" width="' + DW + '" height="' + (PH - MT - MB) + '" fill="none" stroke="#111" stroke-width="2"/>');
  p('<rect x="' + (ML + 6) + '" y="' + (MT + 6) + '" width="' + (DW - 12) + '" height="' + (PH - MT - MB - 12) + '" fill="none" stroke="#555" stroke-width="0.4"/>');

  /* Zone marks */
  var zW = DW / 8;
  'ABCDEFGH'.split('').forEach(function (l, i) {
    var zx = ML + zW * (i + 0.5);
    p('<text x="' + f1(zx) + '" y="' + (MT - 5) + '" text-anchor="middle" font-size="7" fill="#bbb">' + l + '</text>');
    p('<text x="' + f1(zx) + '" y="' + (PH - MB + 11) + '" text-anchor="middle" font-size="7" fill="#bbb">' + l + '</text>');
  });
  for (var zi = 0; zi < 6; zi++) {
    var zy = MT + (WORK_H + TB_H) / 6 * (zi + 0.5);
    p('<text x="' + (ML - 7) + '" y="' + f1(zy + 3) + '" text-anchor="middle" font-size="7" fill="#bbb">' + (zi + 1) + '</text>');
    p('<text x="' + (PW - MR + 8) + '" y="' + f1(zy + 3) + '" text-anchor="middle" font-size="7" fill="#bbb">' + (zi + 1) + '</text>');
  }

  /* Section labels */
  p('<text x="' + (DX + 4) + '" y="' + (DY + 11) + '" font-size="7" fill="#aaa" letter-spacing="2" font-weight="bold">HARNESS TOPOLOGY</text>');
  p('<line x1="' + DX + '" y1="' + (DY + HARNESS_H) + '" x2="' + (DX + DW) + '" y2="' + (DY + HARNESS_H) + '" stroke="#bbb" stroke-width="0.6" stroke-dasharray="5,3"/>');
  p('<text x="' + (DX + 4) + '" y="' + (PIN_Y + 11) + '" font-size="7" fill="#aaa" letter-spacing="2" font-weight="bold">CONNECTOR PIN TABLES</text>');
  p('<line x1="' + (DX + PIN_W + 4) + '" y1="' + PIN_Y + '" x2="' + (DX + PIN_W + 4) + '" y2="' + TB_Y + '" stroke="#bbb" stroke-width="0.6"/>');

  /* ────────────────────────────────────────────
     ECO / REVISION TABLE (top-right)
     ──────────────────────────────────────────── */
  var ex = DX + DW - ECO_W, ey = DY;
  p('<rect x="' + ex + '" y="' + ey + '" width="' + ECO_W + '" height="' + ECO_H + '" fill="#f4f2ea" stroke="#999" stroke-width="0.7"/>');
  p('<rect x="' + ex + '" y="' + ey + '" width="' + ECO_W + '" height="13" fill="#c8c4b0"/>');
  p('<text x="' + (ex + ECO_W / 2) + '" y="' + (ey + 9) + '" text-anchor="middle" font-size="7.5" fill="#111" font-weight="bold" letter-spacing="1">REVISIONS</text>');
  var ecoCols = [22, 44, 34, ECO_W - 100];
  var ecoCxs = [ex + 1];
  ecoCols.forEach(function (w, i) { if (i > 0) ecoCxs.push(ecoCxs[i - 1] + ecoCols[i - 1]); });
  p('<rect x="' + ex + '" y="' + (ey + 13) + '" width="' + ECO_W + '" height="10" fill="#dedad0"/>');
  ['REV', 'DATE', 'DRAW', 'DESCRIPTION'].forEach(function (h2, i) {
    p('<text x="' + (ecoCxs[i] + 2) + '" y="' + (ey + 21) + '" font-size="6" fill="#333" font-weight="bold">' + h2 + '</text>');
  });
  ecoCxs.slice(1).forEach(function (cx) {
    p('<line x1="' + cx + '" y1="' + ey + '" x2="' + cx + '" y2="' + (ey + ECO_H) + '" stroke="#ccc" stroke-width="0.4"/>');
  });
  var ecoRy = ey + 23 + 10;
  p('<text x="' + (ecoCxs[0] + 2) + '" y="' + ecoRy + '" font-size="7" fill="#336699" font-weight="bold">' + xe(S.rev || 'A') + '</text>');
  p('<text x="' + (ecoCxs[1] + 2) + '" y="' + ecoRy + '" font-size="6" fill="#222">' + new Date().toLocaleDateString('en-GB') + '</text>');
  p('<text x="' + (ecoCxs[2] + 2) + '" y="' + ecoRy + '" font-size="6" fill="#222">' + xe(S.drawnBy || '') + '</text>');
  p('<text x="' + (ecoCxs[3] + 2) + '" y="' + ecoRy + '" font-size="6" fill="#222">Initial Release</text>');

  /* ────────────────────────────────────────────
     HARNESS TOPOLOGY DIAGRAM
     ──────────────────────────────────────────── */
  var hNodes = H.nodes || [], hSegs = H.segs || [];
  var hZX = DX + 6, hZY = DY + 14;
  var hZW = DW - ECO_W - 12;
  var hZH = HARNESS_H - 24;

  /* Compute bounding box */
  var xs = hNodes.map(function (n) { return n.x; });
  var ys = hNodes.map(function (n) { return n.y; });
  var mnX = xs.length ? Math.min.apply(null, xs) - 80 : -250;
  var mxX = xs.length ? Math.max.apply(null, xs) + 80 : 250;
  var mnY = ys.length ? Math.min.apply(null, ys) - 60 : -120;
  var mxY = ys.length ? Math.max.apply(null, ys) + 60 : 120;
  var rnX = mxX - mnX || 400, rnY = mxY - mnY || 200;
  var scX = hZW / rnX, scY = hZH / rnY;
  var hSc = Math.min(scX, scY) * 0.85;
  var hOX = hZX + hZW / 2 - (mnX + rnX / 2) * hSc;
  var hOY = hZY + hZH / 2 - (mnY + rnY / 2) * hSc;

  function mN(n) { return { x: hOX + n.x * hSc, y: hOY + n.y * hSc }; }

  /* Connector map for leader lines */
  var connMap = {};
  hNodes.forEach(function (n) { connMap[n.id] = mN(n); });

  /* Draw cable segments */
  hSegs.forEach(function (seg) {
    var n1 = null, n2 = null;
    hNodes.forEach(function (n) { if (n.id === seg.from) n1 = n; if (n.id === seg.to) n2 = n; });
    if (!n1 || !n2) return;

    var p1 = mN(n1), p2 = mN(n2);
    var a1 = (n1.angle || 0) * Math.PI / 180, a2 = (n2.angle || 0) * Math.PI / 180;
    var stub = Math.max(18, Math.min(50, 28 * hSc));
    var s1 = { x: p1.x + Math.cos(a1) * stub, y: p1.y + Math.sin(a1) * stub };
    var s2 = { x: p2.x + Math.cos(a2) * stub, y: p2.y + Math.sin(a2) * stub };
    var bpts = (seg.pts || []).map(function (b) { return { x: hOX + b.x * hSc, y: hOY + b.y * hSc }; });
    var pts = [s1].concat(bpts).concat([s2]);

    /* Cable thickness by wire count */
    var thick = Math.max(5, Math.min(30, 5 + (seg.wires || []).length * 2.3));

    /* Build path */
    var d = 'M' + f1(pts[0].x) + ' ' + f1(pts[0].y);
    for (var pi = 1; pi < pts.length; pi++) d += ' L' + f1(pts[pi].x) + ' ' + f1(pts[pi].y);

    /* Shadow */
    p('<path d="' + d + '" stroke="rgba(0,0,0,0.18)" stroke-width="' + (thick + 4) + '" fill="none" stroke-linecap="round" stroke-linejoin="round"/>');
    /* Sheath */
    p('<path d="' + d + '" stroke="#1e1c16" stroke-width="' + thick + '" fill="none" stroke-linecap="round" stroke-linejoin="round"/>');
    /* Highlight */
    p('<path d="' + d + '" stroke="rgba(170,155,118,0.35)" stroke-width="' + (thick * 0.34) + '" fill="none" stroke-linecap="round" stroke-linejoin="round"/>');

    /* Braid hatch marks */
    for (var si = 0; si < pts.length - 1; si++) {
      var ax = pts[si].x, ay = pts[si].y, bx = pts[si + 1].x, by = pts[si + 1].y;
      var sl = Math.sqrt((bx - ax) * (bx - ax) + (by - ay) * (by - ay));
      if (sl < 2) continue;
      var ag = Math.atan2(by - ay, bx - ax);
      var nx = Math.cos(ag + Math.PI / 2) * thick * 0.44;
      var ny = Math.sin(ag + Math.PI / 2) * thick * 0.44;
      var sp = Math.max(7, thick * 0.9);
      for (var t = sp / 2; t < sl - sp / 2; t += sp) {
        var tx = ax + Math.cos(ag) * t, ty = ay + Math.sin(ag) * t;
        var dx2 = Math.cos(ag) * 4, dy2 = Math.sin(ag) * 4;
        p('<line x1="' + f1(tx + nx) + '" y1="' + f1(ty + ny) + '" x2="' + f1(tx - nx + dx2) + '" y2="' + f1(ty - ny + dy2) + '" stroke="rgba(195,182,148,0.32)" stroke-width="0.65"/>');
        p('<line x1="' + f1(tx - nx) + '" y1="' + f1(ty - ny) + '" x2="' + f1(tx + nx + dx2) + '" y2="' + f1(ty + ny + dy2) + '" stroke="rgba(195,182,148,0.32)" stroke-width="0.65"/>');
      }
    }

    /* Wire color stripes */
    var wCols = [];
    (seg.wires || []).forEach(function (wid) {
      for (var i = 0; i < S.wires.length; i++) {
        if (S.wires[i].id === wid) { wCols.push(xc(S.wires[i].color || '#888')); break; }
      }
    });
    var maxS = Math.min(wCols.length, 10);
    if (maxS > 0) {
      var sw = Math.max(0.8, thick * 0.1), spread = thick * 0.28;
      wCols.slice(0, maxS).forEach(function (col, ci) {
        var t2 = maxS === 1 ? 0 : ((ci / (maxS - 1)) * 2 - 1) * spread;
        var dOff = '';
        for (var pi2 = 0; pi2 < pts.length - 1; pi2++) {
          var ddx = pts[pi2 + 1].x - pts[pi2].x, ddy = pts[pi2 + 1].y - pts[pi2].y;
          var ll = Math.sqrt(ddx * ddx + ddy * ddy) || 1;
          var nnx = -ddy / ll * t2, nny = ddx / ll * t2;
          if (pi2 === 0) dOff = 'M' + f1(pts[0].x + nnx) + ' ' + f1(pts[0].y + nny);
          dOff += ' L' + f1(pts[pi2 + 1].x + nnx) + ' ' + f1(pts[pi2 + 1].y + nny);
        }
        p('<path d="' + dOff + '" stroke="' + col + '" stroke-width="' + f1(sw) + '" fill="none" stroke-linecap="butt"/>');
      });
    }

    /* Dimension label */
    if (seg.lengthMm > 0 && pts.length >= 2) {
      var totLen = 0, cumL = [0];
      for (var di = 0; di < pts.length - 1; di++) {
        var ddx2 = pts[di + 1].x - pts[di].x, ddy2 = pts[di + 1].y - pts[di].y;
        totLen += Math.sqrt(ddx2 * ddx2 + ddy2 * ddy2); cumL.push(totLen);
      }
      var half = totLen / 2, mid = { x: 0, y: 0 }, mAng = 0;
      for (var di2 = 1; di2 < pts.length; di2++) {
        if (cumL[di2] >= half) {
          var tt = (half - cumL[di2 - 1]) / (cumL[di2] - cumL[di2 - 1]);
          mid = { x: pts[di2 - 1].x + (pts[di2].x - pts[di2 - 1].x) * tt, y: pts[di2 - 1].y + (pts[di2].y - pts[di2 - 1].y) * tt };
          mAng = Math.atan2(pts[di2].y - pts[di2 - 1].y, pts[di2].x - pts[di2 - 1].x); break;
        }
      }
      var py2 = Math.sin(mAng + Math.PI / 2);
      var side = py2 <= 0 ? 1 : -1;
      var px3 = Math.cos(mAng + Math.PI / 2) * side, py3 = Math.sin(mAng + Math.PI / 2) * side;
      var off = thick / 2 + 22;
      var lx = mid.x + px3 * off, ly = mid.y + py3 * off;
      var ep1 = { x: pts[0].x + px3 * off, y: pts[0].y + py3 * off };
      var ep2 = { x: pts[pts.length - 1].x + px3 * off, y: pts[pts.length - 1].y + py3 * off };
      var dimTxt = (seg.label ? seg.label + '  ' : '') + seg.lengthMm + ' mm' + (S.lengthTol ? '  +/-' + S.lengthTol : '');
      var drawAng = (mAng > Math.PI / 2 || mAng < -Math.PI / 2) ? mAng + Math.PI : mAng;
      /* Extension lines */
      p('<line x1="' + f1(pts[0].x) + '" y1="' + f1(pts[0].y) + '" x2="' + f1(ep1.x) + '" y2="' + f1(ep1.y) + '" stroke="#336699" stroke-width="0.65" stroke-dasharray="2.5,2"/>');
      p('<line x1="' + f1(pts[pts.length - 1].x) + '" y1="' + f1(pts[pts.length - 1].y) + '" x2="' + f1(ep2.x) + '" y2="' + f1(ep2.y) + '" stroke="#336699" stroke-width="0.65" stroke-dasharray="2.5,2"/>');
      /* Dim line */
      p('<line x1="' + f1(ep1.x) + '" y1="' + f1(ep1.y) + '" x2="' + f1(ep2.x) + '" y2="' + f1(ep2.y) + '" stroke="#336699" stroke-width="0.9"/>');
      /* Arrows */
      function arr(ax2, ay2, aa) {
        var s = 8, a1 = aa + 2.65, a2 = aa - 2.65;
        p('<line x1="' + f1(ax2) + '" y1="' + f1(ay2) + '" x2="' + f1(ax2 + Math.cos(a1) * s) + '" y2="' + f1(ay2 + Math.sin(a1) * s) + '" stroke="#336699" stroke-width="0.9"/>');
        p('<line x1="' + f1(ax2) + '" y1="' + f1(ay2) + '" x2="' + f1(ax2 + Math.cos(a2) * s) + '" y2="' + f1(ay2 + Math.sin(a2) * s) + '" stroke="#336699" stroke-width="0.9"/>');
      }
      arr(ep1.x, ep1.y, Math.atan2(ep2.y - ep1.y, ep2.x - ep1.x) + Math.PI);
      arr(ep2.x, ep2.y, Math.atan2(ep1.y - ep2.y, ep1.x - ep2.x) + Math.PI);
      /* Label box */
      var tw = dimTxt.length * 5.8 + 12;
      p('<g transform="translate(' + f1(lx) + ',' + f1(ly) + ') rotate(' + f1(drawAng * 180 / Math.PI) + ')">');
      p('<rect x="' + f1(-tw / 2) + '" y="-10" width="' + f1(tw) + '" height="12" rx="1.5" fill="rgba(247,245,238,0.97)" stroke="#336699" stroke-width="0.7"/>');
      p('<text x="0" y="0" text-anchor="middle" font-size="8.5" fill="#336699" font-weight="bold">' + xe(dimTxt) + '</text>');
      p('</g>');
    }
  });

  /* Draw connector bodies */
  hNodes.forEach(function (nd, idx) {
    var m = mN(nd);
    if (nd.isJunction) {
      p('<circle cx="' + f1(m.x) + '" cy="' + f1(m.y) + '" r="8" fill="#2c2820" stroke="#888" stroke-width="1.2"/>');
      p('<text x="' + f1(m.x) + '" y="' + f1(m.y + 3) + '" text-anchor="middle" font-size="7" fill="#f0e8d0" font-weight="bold">' + xe(nd.label || 'J') + '</text>');
      return;
    }
    var lib = CL[nd.connId]; if (!lib) return;
    var pins = lib.pins;
    var bw = Math.max(22, Math.min(42, 20 + pins * 1.1));
    var bh = Math.max(18, Math.min(38, 12 + pins * 1.7));
    var ang = nd.angle || 0;
    var gid = 'cg_' + nd.id.replace(/[^a-z0-9]/gi, '_');
    p('<defs><linearGradient id="' + gid + '" x1="0" y1="0" x2="0" y2="1">');
    p('<stop offset="0%" stop-color="#aea698"/><stop offset="40%" stop-color="#c6beb0"/>');
    p('<stop offset="60%" stop-color="#b6aea0"/><stop offset="100%" stop-color="#706860"/>');
    p('</linearGradient></defs>');
    p('<g transform="translate(' + f1(m.x) + ',' + f1(m.y) + ') rotate(' + ang + ')">');
    p('<rect x="' + f1(-bw / 2 + 2) + '" y="' + f1(-bh / 2 + 2) + '" width="' + bw + '" height="' + bh + '" rx="3" fill="rgba(0,0,0,0.2)"/>');
    p('<rect x="' + f1(-bw / 2) + '" y="' + f1(-bh / 2) + '" width="' + bw + '" height="' + bh + '" rx="3" fill="url(#' + gid + ')" stroke="#50483c" stroke-width="1"/>');
    p('<rect x="' + f1(-bw * 0.42) + '" y="' + f1(-bh * 0.40) + '" width="' + f1(bw * 0.84) + '" height="' + f1(bh * 0.80) + '" rx="2" fill="#282010" stroke="#180808" stroke-width="0.5"/>');
    p('<rect x="' + f1(-bw * 0.22) + '" y="' + f1(-bh / 2 - 4) + '" width="' + f1(bw * 0.44) + '" height="4.5" rx="2" fill="#807868" stroke="#605848" stroke-width="0.6"/>');
    var cols2 = Math.ceil(Math.sqrt(pins)), rows2 = Math.ceil(pins / cols2);
    var cw2 = bw * 0.84 / cols2, ch2 = bh * 0.8 / rows2;
    var dr = Math.max(1.5, Math.min(3.8, cw2 * 0.3));
    lib.pinout.forEach(function (pp, i) {
      var c = i % cols2, r = Math.floor(i / cols2);
      var px4 = -bw * 0.42 + cw2 * (c + 0.5), py4 = -bh * 0.4 + ch2 * (r + 0.5);
      p('<circle cx="' + f1(px4) + '" cy="' + f1(py4) + '" r="' + dr + '" fill="' + xc(pp.c) + '" stroke="rgba(0,0,0,0.55)" stroke-width="0.4"/>');
    });
    p('</g>');
    var itemN = nd.itemNo || String.fromCharCode(65 + idx);
    p('<text x="' + f1(m.x) + '" y="' + f1(m.y + bh / 2 + 12) + '" text-anchor="middle" font-size="9.5" fill="#111" font-weight="bold">' + xe(nd.label || '?') + '</text>');
    p('<text x="' + f1(m.x) + '" y="' + f1(m.y + bh / 2 + 21) + '" text-anchor="middle" font-size="7.5" fill="#555">' + xe(lib.short) + '</text>');
    /* Item balloon */
    var bx2 = m.x + bw / 2 + 18, by2 = m.y - bh / 2 - 16;
    p('<line x1="' + f1(bx2) + '" y1="' + f1(by2) + '" x2="' + f1(m.x) + '" y2="' + f1(m.y) + '" stroke="#444" stroke-width="0.8"/>');
    p('<circle cx="' + f1(bx2) + '" cy="' + f1(by2) + '" r="9" fill="white" stroke="#111" stroke-width="1.2"/>');
    p('<text x="' + f1(bx2) + '" y="' + f1(by2 + 3.5) + '" text-anchor="middle" font-size="8.5" fill="#111" font-weight="bold">' + xe(itemN) + '</text>');
  });

  /* ────────────────────────────────────────────
     PIN TABLES
     ──────────────────────────────────────────── */
  var pinNodes = hNodes.filter(function (n) { return !n.isJunction && CL[n.connId]; });
  var ptRowH = 10, ptHdrH = 15, ptColH = 10;
  /* Calculate how many columns fit */
  var minPtW = 160;
  var pinCols = Math.max(1, Math.min(pinNodes.length, Math.floor((PIN_W - 4) / (minPtW + 4))));
  var ptW = Math.floor((PIN_W - 4 - 4 * (pinCols - 1)) / pinCols);
  var ptStartX = DX + 4, ptStartY = PIN_Y + 14;

  pinNodes.forEach(function (nd, idx) {
    var lib = CL[nd.connId]; if (!lib) return;
    var col = idx % pinCols, row2 = Math.floor(idx / pinCols);
    var px5 = ptStartX + col * (ptW + 4);
    var py5 = ptStartY + row2 * (ptHdrH + ptColH + lib.pinout.length * ptRowH + 6);
    if (py5 + ptHdrH + lib.pinout.length * ptRowH > TB_Y - 4) return;
    var tH = ptHdrH + ptColH + lib.pinout.length * ptRowH + 2;
    var m2 = connMap[nd.id];
    var itemN2 = nd.itemNo || String.fromCharCode(65 + idx);

    p('<rect x="' + px5 + '" y="' + py5 + '" width="' + ptW + '" height="' + tH + '" fill="#fff" stroke="#b0a890" stroke-width="0.8"/>');
    p('<rect x="' + px5 + '" y="' + py5 + '" width="' + ptW + '" height="' + ptHdrH + '" fill="#c4bfb0"/>');
    p('<text x="' + (px5 + 5) + '" y="' + (py5 + 11) + '" font-size="8.5" fill="#111" font-weight="bold">'
      + xe(nd.label) + ' -- ' + xe(lib.short) + ' (' + lib.pins + 'P)</text>');
    /* Balloon in header */
    p('<circle cx="' + (px5 + ptW - 12) + '" cy="' + (py5 + 8) + '" r="7" fill="white" stroke="#222" stroke-width="1"/>');
    p('<text x="' + (px5 + ptW - 12) + '" y="' + (py5 + 11) + '" text-anchor="middle" font-size="7.5" fill="#111" font-weight="bold">' + xe(itemN2) + '</text>');
    /* Leader line to connector */
    if (m2) {
      p('<line x1="' + (px5 + ptW - 12) + '" y1="' + (py5 - 2) + '" x2="' + f1(m2.x) + '" y2="' + f1(m2.y) + '" stroke="#bbb" stroke-width="0.7" stroke-dasharray="3,2.5"/>');
    }
    /* Column headers */
    var cws = [13, ptW * 0.23, ptW * 0.22, ptW * 0.13, ptW * 0.15, ptW * 0.14];
    var cxs = [px5 + 2];
    cws.forEach(function (w, i) { if (i > 0) cxs.push(cxs[i - 1] + cws[i - 1]); });
    p('<rect x="' + px5 + '" y="' + (py5 + ptHdrH) + '" width="' + ptW + '" height="' + ptColH + '" fill="#dedad0"/>');
    ['#', 'NAME', 'SIGNAL', 'AWG', 'CLR', '->TO'].forEach(function (h2, i) {
      p('<text x="' + (cxs[i] + 1) + '" y="' + (py5 + ptHdrH + 7) + '" font-size="6.5" fill="#333" font-weight="bold">' + h2 + '</text>');
    });
    cxs.slice(1).forEach(function (cx) {
      p('<line x1="' + cx + '" y1="' + py5 + '" x2="' + cx + '" y2="' + (py5 + tH) + '" stroke="#ddd" stroke-width="0.4"/>');
    });
    /* Pin rows */
    lib.pinout.forEach(function (pp, i) {
      var ry = py5 + ptHdrH + ptColH + ptRowH * (i + 1);
      if (i % 2 === 0) p('<rect x="' + (px5 + 1) + '" y="' + (ry - ptRowH + 1) + '" width="' + (ptW - 2) + '" height="' + ptRowH + '" fill="#f5f3ee"/>');
      var wfp = null;
      S.wires.forEach(function (w) {
        if ((w.fromEl === nd.id && String(w.fromPin) === String(pp.id)) ||
            (w.toEl   === nd.id && String(w.toPin)   === String(pp.id))) wfp = w;
      });
      var toPin = '--';
      if (wfp) {
        var oe = null;
        S.elements.forEach(function (e) { if (e.id === (wfp.fromEl === nd.id ? wfp.toEl : wfp.fromEl)) oe = e; });
        toPin = (oe ? oe.label || '?' : '?') + '.' + (wfp.fromEl === nd.id ? wfp.toPin : wfp.fromPin);
      }
      var sig = (wfp ? wfp.signal || pp.sig : pp.sig) || '';
      [pp.id, pp.n.substring(0, 10), sig.substring(0, 8), pp.g.substring(0, 5)].forEach(function (d, ci) {
        p('<text x="' + (cxs[ci] + 1) + '" y="' + ry + '" font-size="' + (ci === 0 ? 7.5 : 7) + '" fill="' + (ci === 0 ? '#336699' : '#111') + '"' + (ci === 0 ? ' font-weight="bold"' : '') + '>' + xe(String(d)) + '</text>');
      });
      p('<circle cx="' + (cxs[4] + 7) + '" cy="' + (ry - 4) + '" r="4" fill="' + xc(pp.c) + '" stroke="rgba(0,0,0,0.5)" stroke-width="0.5"/>');
      p('<text x="' + (cxs[5] + 1) + '" y="' + ry + '" font-size="6.5" fill="#336699" font-weight="bold">' + xe(toPin.substring(0, 10)) + '</text>');
      p('<line x1="' + (px5 + 1) + '" y1="' + (ry + 1.5) + '" x2="' + (px5 + ptW - 1) + '" y2="' + (ry + 1.5) + '" stroke="#e8e4dc" stroke-width="0.3"/>');
    });
  });

  /* ────────────────────────────────────────────
     BOM TABLE
     ──────────────────────────────────────────── */
  var bx3 = DX + PIN_W + 8, by3 = PIN_Y + 14;
  var bw3 = DW - PIN_W - 12;
  var bomAll = [];
  pinNodes.forEach(function (nd) {
    var lib = CL[nd.connId]; if (!lib) return;
    bomAll.push({ pn: lib.pn || lib.id, desc: lib.name, qty: 1, unit: 'EA' });
  });
  S.bomItems.forEach(function (it) {
    bomAll.push({ pn: it.pn || '', desc: it.desc || '', qty: it.qty || 1, unit: it.unit || 'EA' });
  });
  var bRH = 9, bHdrH = 26;
  var bomH = Math.min(PIN_H - 20, bHdrH + bomAll.length * bRH + 4);
  p('<rect x="' + bx3 + '" y="' + by3 + '" width="' + bw3 + '" height="' + bomH + '" fill="#f8f7f2" stroke="#999" stroke-width="0.7"/>');
  p('<rect x="' + bx3 + '" y="' + by3 + '" width="' + bw3 + '" height="14" fill="#c4bfb0"/>');
  p('<text x="' + (bx3 + bw3 / 2) + '" y="' + (by3 + 10) + '" text-anchor="middle" font-size="8" fill="#111" font-weight="bold" letter-spacing="1">BILL OF MATERIALS</text>');
  var bCws = [18, bw3 * 0.28, bw3 * 0.38, 22, 20];
  var bCxs = [bx3 + 1];
  bCws.forEach(function (w, i) { if (i > 0) bCxs.push(bCxs[i - 1] + bCws[i - 1]); });
  p('<rect x="' + bx3 + '" y="' + (by3 + 14) + '" width="' + bw3 + '" height="11" fill="#dedad0"/>');
  ['#', 'PART NUMBER', 'DESCRIPTION', 'QTY', 'UN'].forEach(function (h2, i) {
    p('<text x="' + (bCxs[i] + 1) + '" y="' + (by3 + 22) + '" font-size="6" fill="#333" font-weight="bold">' + h2 + '</text>');
  });
  bCxs.slice(1).forEach(function (cx) {
    p('<line x1="' + cx + '" y1="' + by3 + '" x2="' + cx + '" y2="' + (by3 + bomH) + '" stroke="#ccc" stroke-width="0.4"/>');
  });
  bomAll.forEach(function (it, i) {
    var ry2 = by3 + 25 + bRH * (i + 1);
    if (ry2 > by3 + bomH - 2) return;
    if (i % 2 === 0) p('<rect x="' + (bx3 + 1) + '" y="' + (ry2 - bRH + 1) + '" width="' + (bw3 - 2) + '" height="' + bRH + '" fill="#f3f1ea"/>');
    p('<text x="' + (bCxs[0] + 1) + '" y="' + ry2 + '" font-size="6.5" fill="#336699" font-weight="bold">' + (i + 1) + '</text>');
    p('<text x="' + (bCxs[1] + 1) + '" y="' + ry2 + '" font-size="6" fill="#222">' + xe(String(it.pn).substring(0, 20)) + '</text>');
    p('<text x="' + (bCxs[2] + 1) + '" y="' + ry2 + '" font-size="6" fill="#222">' + xe(String(it.desc).substring(0, 28)) + '</text>');
    p('<text x="' + (bCxs[3] + 1) + '" y="' + ry2 + '" font-size="6" fill="#333" text-anchor="middle">' + it.qty + '</text>');
    p('<text x="' + (bCxs[4] + 1) + '" y="' + ry2 + '" font-size="6" fill="#555">' + xe(it.unit) + '</text>');
    p('<line x1="' + (bx3 + 1) + '" y1="' + (ry2 + 1) + '" x2="' + (bx3 + bw3 - 1) + '" y2="' + (ry2 + 1) + '" stroke="#e8e4d8" stroke-width="0.3"/>');
  });
  /* RoHS */
  p('<rect x="' + (bx3 + bw3 - 46) + '" y="' + (by3 + bomH - 13) + '" width="43" height="11" fill="none" stroke="#27ae60" stroke-width="1.5"/>');
  p('<text x="' + (bx3 + bw3 - 24) + '" y="' + (by3 + bomH - 4) + '" text-anchor="middle" font-size="7" fill="#27ae60" font-weight="bold">RoHS OK</text>');

  /* ────────────────────────────────────────────
     NOTES
     ──────────────────────────────────────────── */
  var notesX = DX + 4, notesY = TB_Y - 52, notesW = PIN_W - 4, notesH = 50;
  p('<rect x="' + notesX + '" y="' + notesY + '" width="' + notesW + '" height="' + notesH + '" fill="#f8f7f2" stroke="#999" stroke-width="0.7"/>');
  p('<rect x="' + notesX + '" y="' + notesY + '" width="22" height="' + notesH + '" fill="#c4bfb0"/>');
  p('<text x="' + (notesX + 11) + '" y="' + (notesY + notesH / 2 + 4) + '" text-anchor="middle" font-size="8" fill="#333" font-weight="bold" transform="rotate(-90 ' + (notesX + 11) + ' ' + (notesY + notesH / 2) + ')">NOTES</text>');
  (S.notes || []).forEach(function (note, i) {
    var ty = notesY + 12 + i * 12;
    if (ty > notesY + notesH - 4) return;
    p('<circle cx="' + (notesX + 30) + '" cy="' + (ty - 4) + '" r="5.5" fill="none" stroke="#333" stroke-width="1.1"/>');
    p('<text x="' + (notesX + 30) + '" y="' + (ty - 1) + '" text-anchor="middle" font-size="6.5" fill="#333" font-weight="bold">' + (i + 1) + '</text>');
    p('<text x="' + (notesX + 41) + '" y="' + ty + '" font-size="7" fill="#222">' + xe(note.length > 90 ? note.substring(0, 88) + '...' : note) + '</text>');
  });

  /* ────────────────────────────────────────────
     TITLE BLOCK
     ──────────────────────────────────────────── */
  var TBX = ML + 5, TBW = DW - 10;
  var today = new Date().toLocaleDateString('en-GB');
  p('<rect x="' + TBX + '" y="' + TB_Y + '" width="' + TBW + '" height="' + TB_H + '" fill="#f0ede4" stroke="#333" stroke-width="0.8"/>');
  /* Right panel */
  var RP_W = 270, RP_X = TBX + TBW - RP_W;
  p('<rect x="' + RP_X + '" y="' + TB_Y + '" width="' + RP_W + '" height="' + TB_H + '" fill="#e8e4d8" stroke="#333" stroke-width="0.6"/>');
  p('<line x1="' + RP_X + '" y1="' + TB_Y + '" x2="' + RP_X + '" y2="' + (TB_Y + TB_H) + '" stroke="#333" stroke-width="1"/>');
  /* Company header */
  p('<rect x="' + RP_X + '" y="' + TB_Y + '" width="' + RP_W + '" height="18" fill="#d0ccc0"/>');
  p('<text x="' + (RP_X + RP_W / 2) + '" y="' + (TB_Y + 13) + '" text-anchor="middle" font-size="12" fill="#1a1a1a" font-weight="bold" letter-spacing="2">' + xe(S.company || 'COMPANY') + '</text>');
  p('<line x1="' + RP_X + '" y1="' + (TB_Y + 18) + '" x2="' + (RP_X + RP_W) + '" y2="' + (TB_Y + 18) + '" stroke="#aaa" stroke-width="0.5"/>');
  p('<line x1="' + (RP_X + RP_W / 2) + '" y1="' + (TB_Y + 18) + '" x2="' + (RP_X + RP_W / 2) + '" y2="' + (TB_Y + TB_H) + '" stroke="#aaa" stroke-width="0.5"/>');
  /* Fields */
  [
    [RP_X + 2,          TB_Y + 26, 'DRAWN BY', S.drawnBy || '--', 8.5],
    [RP_X + 2,          TB_Y + 38, 'DATE',     today,             8.5],
    [RP_X + 2,          TB_Y + 52, 'APPROVED', '--',              8.5],
    [RP_X + RP_W/2 + 2, TB_Y + 26, 'DWG NO.',  S.dwgNo || '--',  8.5],
    [RP_X + RP_W/2 + 2, TB_Y + 36, 'P/N',      S.partNo || '--', 9  ],
    [RP_X + RP_W/2 + 2, TB_Y + 50, 'REV',      S.rev || 'A',     14 ],
  ].forEach(function (f) {
    p('<text x="' + f[0] + '" y="' + (f[1] - 8) + '" font-size="5.5" fill="#888" font-weight="bold">' + f[2] + '</text>');
    p('<text x="' + f[0] + '" y="' + f[1] + '" font-size="' + f[4] + '" fill="#111" font-weight="bold">' + xe(f[3]) + '</text>');
  });
  p('<text x="' + (RP_X + RP_W - 2) + '" y="' + (TB_Y + TB_H - 4) + '" text-anchor="end" font-size="7" fill="#444" font-weight="bold">SHEET 1/1</text>');
  /* Left panel: title */
  p('<text x="' + (TBX + 5) + '" y="' + (TB_Y + 11) + '" font-size="6" fill="#666" font-weight="bold">TITLE</text>');
  p('<text x="' + (TBX + 5) + '" y="' + (TB_Y + 26) + '" font-size="14" fill="#111" font-weight="bold">' + xe(S.title || '--') + '</text>');
  p('<text x="' + (TBX + 5) + '" y="' + (TB_Y + 38) + '" font-size="8" fill="#555">' + xe(S.company || '') + '</text>');
  p('<text x="' + (TBX + 5) + '" y="' + (TB_Y + 48) + '" font-size="7" fill="#666">TOLERANCE: +/-' + (S.lengthTol || 20) + 'mm UNLESS NOTED   ALL DIM IN mm   SCALE: NTS</text>');
  /* RoHS badge */
  p('<rect x="' + (RP_X - 52) + '" y="' + (TB_Y + TB_H - 15) + '" width="48" height="12" fill="none" stroke="#27ae60" stroke-width="1.5"/>');
  p('<text x="' + (RP_X - 28) + '" y="' + (TB_Y + TB_H - 5) + '" text-anchor="middle" font-size="7" fill="#27ae60" font-weight="bold">RoHS OK</text>');

  p('</svg>');
  return out.join('\n');
}

function render(){ dwgRegen(); }
