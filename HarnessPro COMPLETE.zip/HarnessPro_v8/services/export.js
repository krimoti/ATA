'use strict';
/* SERVICE: Export outputs */


function exportJSON(){
  var d={version:'v7',state:JSON.parse(JSON.stringify(S)),
         harness:JSON.parse(JSON.stringify(H)),
         partDB:JSON.parse(JSON.stringify(PART_DB)),
         templates:JSON.parse(JSON.stringify(SC_TEMPLATES)),
         exportedAt:new Date().toISOString()};
  var b=new Blob([JSON.stringify(d,null,2)],{type:'application/json'});
  var a=document.createElement('a');a.href=URL.createObjectURL(b);
  a.download='MOTI_'+(S.dwgNo||'project')+'_'+new Date().toISOString().slice(0,10)+'.json';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast('Project exported: '+(S.dwgNo||'project'));
}

function importJSON(input){
  var file=input.files[0];if(!file)return;
  var reader=new FileReader();
  reader.onload=function(ev){
    try{
      var d=JSON.parse(ev.target.result);
      if(!confirm('Import project? This will replace current data.'))return;
      var st=d.state||d;
      for(var k in st) S[k]=st[k];
      if(d.harness){H.nodes=d.harness.nodes||[];H.segs=d.harness.segs||[];}
      if(d.partDB) PART_DB=d.partDB;
      if(d.templates) SC_TEMPLATES=d.templates;
      syncCustomConnectors();saveState();buildSidebar();renderAll();syncTBAll();
      toast('Imported: '+(S.title||'project'));
    }catch(e){toast('Import error: '+e.message,true);}
  };
  reader.readAsText(file);input.value='';
}

function saveHTML(){
  var b=new Blob([document.documentElement.outerHTML],{type:'text/html'});
  var a=document.createElement('a');
  a.href=URL.createObjectURL(b);
  a.download='MOTI_'+(S.dwgNo||'drawing')+'.html';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast('HTML saved');
}

/* ── BOM CSV export ── */
function exportBOMCSV(){
  var rows = [['ITEM','PART NUMBER','DESCRIPTION','CATEGORY','QTY','UNIT','STANDARD']];
  /* Auto-include connectors from canvas */
  var connEls=S.elements.filter(function(e){return e.kind==='connector';});
  connEls.forEach(function(el,i){
    var lib=CL[el.connId];if(!lib)return;
    rows.push([i+1, lib.pn||lib.id, lib.name, 'CONNECTOR', 1, 'EA', lib.std||'']);
  });
  /* Manual BOM items */
  S.bomItems.forEach(function(it,i){
    rows.push([connEls.length+i+1, it.pn||'', it.desc||'', it.cat||'', it.qty||1, it.unit||'EA', '']);
  });
  var csv = rows.map(function(r){
    return r.map(function(c){return '"'+String(c).replace(/"/g,'""')+'"';}).join(',');
  }).join('\r\n');
  csv = '\uFEFF' + csv; /* BOM for Excel UTF-8 */
  var b=new Blob([csv],{type:'text/csv;charset=utf-8'});
  var a=document.createElement('a');a.href=URL.createObjectURL(b);
  a.download='BOM_'+(S.dwgNo||'project')+'_'+new Date().toISOString().slice(0,10)+'.csv';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast('BOM exported: '+rows.length+' items');
}

/* ── Point-to-Point Wire List CSV ── */
function exportP2P(){
  var rows=[['WIRE#','FROM CONNECTOR','FROM PIN','FROM PIN NAME','TO CONNECTOR','TO PIN','TO PIN NAME','SIGNAL','GAUGE','COLOR','LENGTH mm','STRIP A mm','STRIP B mm','CUT LENGTH mm']];
  var connEls=S.elements.filter(function(e){return e.kind==='connector';});

  S.wires.forEach(function(w,i){
    if(!w.fromEl||!w.toEl) return;
    var fromEl=null,toEl=null;
    connEls.forEach(function(e){if(e.id===w.fromEl)fromEl=e;if(e.id===w.toEl)toEl=e;});
    if(!fromEl||!toEl) return;
    var libF=CL[fromEl.connId],libT=CL[toEl.connId];
    var fromPinName='',toPinName='';
    if(libF)(libF.pinout||[]).forEach(function(p){if(String(p.id)===String(w.fromPin))fromPinName=p.n;});
    if(libT)(libT.pinout||[]).forEach(function(p){if(String(p.id)===String(w.toPin))toPinName=p.n;});
    var sf=S.stripFrom||8, st=S.stripTo||8, cable=S.cableLength||500;
    rows.push([
      w.wireNum||String(i+1).padStart(3,'0'),
      fromEl.label||fromEl.id,
      w.fromPin||'',
      fromPinName,
      toEl.label||toEl.id,
      w.toPin||'',
      toPinName,
      w.signal||'',
      w.gauge||'',
      w.colorAbbr||(w.color||''),
      cable,
      sf,
      st,
      cable+sf+st
    ]);
  });

  if(rows.length<2){toast('No wires to export',true);return;}
  var csv=rows.map(function(r){
    return r.map(function(c){return '"'+String(c).replace(/"/g,'""')+'"';}).join(',');
  }).join('\r\n');
  csv='\uFEFF'+csv;
  var b=new Blob([csv],{type:'text/csv;charset=utf-8'});
  var a=document.createElement('a');a.href=URL.createObjectURL(b);
  a.download='P2P_'+(S.dwgNo||'project')+'_'+new Date().toISOString().slice(0,10)+'.csv';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast('P2P wire list exported: '+(rows.length-1)+' wires');
}

/* ── Harness Summary Report (HTML) ── */
function exportReport(){
  var connEls=S.elements.filter(function(e){return e.kind==='connector';});
  var totalLen=S.wires.length * (S.cableLength||500) / 1000; /* approx total m */
  var today=new Date().toLocaleDateString('en-GB');

  var html='<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'+
    (S.title||'Cable Assembly')+' -- Report</title><style>';
  html+='body{font-family:\'Courier New\',monospace;background:#fff;color:#111;margin:20px;font-size:11px}';
  html+='h1{font-size:18px;border-bottom:2px solid #111;padding-bottom:6px}';
  html+='h2{font-size:12px;margin-top:16px;color:#336699;letter-spacing:2px;text-transform:uppercase}';
  html+='table{width:100%;border-collapse:collapse;margin:8px 0}';
  html+='th{background:#c4bfb0;padding:4px 8px;text-align:left;font-size:10px;border:1px solid #999}';
  html+='td{padding:3px 8px;border:1px solid #ddd;font-size:10px}';
  html+='tr:nth-child(even){background:#f5f3ee}';
  html+='@media print{body{margin:8px}.no-print{display:none}}';
  html+='</style></head><body>';

  /* Header */
  html+='<h1>'+esc(S.title||'Cable Assembly')+'</h1>';
  html+='<table style="width:auto;margin-bottom:16px"><tr>';
  [['DWG No.',S.dwgNo],['P/N',S.partNo],['Rev',S.rev],['Drawn By',S.drawnBy],
   ['Company',S.company],['Date',today]].forEach(function(f){
    html+='<td style="background:#f0ede4"><b>'+f[0]+':</b></td><td>'+esc(f[1]||'--')+'</td>';
  });
  html+='</tr></table>';

  /* Summary */
  html+='<h2>Summary</h2>';
  html+='<table><tr><th>Item</th><th>Value</th></tr>';
  [['Connectors',connEls.length],
   ['Total wires',S.wires.length],
   ['Cable length',S.cableLength+' mm +/-'+(S.lengthTol||20)],
   ['Strip FROM',S.stripFrom||8+' mm'],['Strip TO',S.stripTo||8+' mm'],
   ['Approx total wire length',totalLen.toFixed(1)+' m']
  ].forEach(function(r){html+='<tr><td>'+r[0]+'</td><td><b>'+r[1]+'</b></td></tr>';});
  html+='</table>';

  /* Connectors */
  html+='<h2>Connectors</h2>';
  html+='<table><tr><th>Label</th><th>Type</th><th>P/N</th><th>Pins</th><th>Side</th></tr>';
  connEls.forEach(function(el){
    var lib=CL[el.connId]||{};
    html+='<tr><td><b>'+esc(el.label||'?')+'</b></td><td>'+esc(lib.name||el.connId)+'</td>'
      +'<td>'+esc(lib.pn||lib.id||'')+'</td><td>'+esc(String(lib.pins||'?'))+'</td>'
      +'<td>'+esc(el.side||'left')+'</td></tr>';
  });
  html+='</table>';

  /* Wire list */
  html+='<h2>Point-to-Point Wire List</h2>';
  html+='<table><tr><th>WIRE#</th><th>FROM</th><th>TO</th><th>SIGNAL</th><th>GAUGE</th><th>COLOR</th></tr>';
  S.wires.forEach(function(w,i){
    var fromEl=null,toEl=null;
    S.elements.forEach(function(e){if(e.id===w.fromEl)fromEl=e;if(e.id===w.toEl)toEl=e;});
    html+='<tr>'
      +'<td>'+esc(w.wireNum||String(i+1).padStart(3,'0'))+'</td>'
      +'<td><b>'+esc((fromEl?fromEl.label:'?')+'.'+w.fromPin)+'</b></td>'
      +'<td><b>'+esc((toEl?toEl.label:'?')+'.'+w.toPin)+'</b></td>'
      +'<td>'+esc(w.signal||'')+'</td>'
      +'<td>'+esc(w.gauge||'')+'</td>'
      +'<td style="background:'+(w.color||'#fff')+';color:'+(w.color?'#fff':'#111')+'">'+esc(w.colorAbbr||w.color||'')+'</td>'
      +'</tr>';
  });
  html+='</table>';

  /* BOM */
  html+='<h2>Bill of Materials</h2>';
  html+='<table><tr><th>#</th><th>P/N</th><th>Description</th><th>Qty</th><th>Unit</th></tr>';
  S.bomItems.forEach(function(it,i){
    html+='<tr><td>'+(i+1)+'</td><td>'+esc(it.pn||'')+'</td><td>'+esc(it.desc||'')+'</td><td>'+esc(String(it.qty||1))+'</td><td>'+esc(it.unit||'EA')+'</td></tr>';
  });
  html+='</table>';

  /* Notes */
  if((S.notes||[]).length){
    html+='<h2>Notes</h2><ol>';
    S.notes.forEach(function(n){html+='<li>'+esc(n)+'</li>';});
    html+='</ol>';
  }

  html+='</body></html>';
  var b=new Blob([html],{type:'text/html;charset=utf-8'});
  var a=document.createElement('a');a.href=URL.createObjectURL(b);
  a.download='Report_'+(S.dwgNo||'project')+'_'+today.replace(/\//g,'-')+'.html';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast('Report exported');
}

/* ── Export dropdown UI ── */
function showExportMenu(){
  var existing=document.getElementById('export-menu');
  if(existing){existing.remove();return;}
  var btn=document.getElementById('btn-export');
  if(!btn)return;
  var rect=btn.getBoundingClientRect();
  var menu=document.createElement('div');
  menu.id='export-menu';
  menu.style.cssText='position:fixed;top:'+(rect.bottom+2)+'px;left:'+rect.left+'px;'
    +'background:#0d0d0d;border:1px solid #444;z-index:9998;min-width:200px;box-shadow:0 4px 20px rgba(0,0,0,0.8)';
  var items=[
    ['Project JSON (.json)',  'exportJSON()'],
    ['BOM CSV (.csv)',        'exportBOMCSV()'],
    ['P2P Wire List (.csv)',  'exportP2P()'],
    ['Full Report (.html)',   'exportReport()'],
    ['Save as HTML',          'saveHTML()'],
    ['ENG Drawing PDF',       'openDwgModal()'],
  ];
  items.forEach(function(item){
    var d=document.createElement('div');
    d.style.cssText='padding:8px 14px;cursor:pointer;font-family:monospace;font-size:9px;'
      +'color:#c8c8c8;border-bottom:1px solid #1a1a1a';
    d.onmouseover=function(){this.style.background='#1a1a1a';this.style.color='#c8a840';};
    d.onmouseout=function(){this.style.background='';this.style.color='#c8c8c8';};
    d.textContent=item[0];
    d.onclick=function(){menu.remove();eval(item[1]);};
    menu.appendChild(d);
  });
  document.body.appendChild(menu);
  setTimeout(function(){
    document.addEventListener('click',function h(e){
      if(!menu.contains(e.target)){menu.remove();document.removeEventListener('click',h);}
    });
  },10);
}

function showTab(id,btn){
  document.querySelectorAll(".tab").forEach(function(t){t.classList.remove("on");});
  document.querySelectorAll(".panel").forEach(function(p){p.classList.remove("on");});
  if(btn) btn.classList.add("on");
  document.getElementById("panel-"+id).classList.add("on");
  if(id==="canvas") setTimeout(resizeCanvas,50);
  if(id==="connectors") renderConnectorEditor();
  if(id==="harness") setTimeout(renderHarness,60);
  if(id==="partdb")    renderPartDB();
  if(id==="sc")        renderSCPanel();
}

function setTheme(v){document.body.className=v;localStorage.setItem("moti_theme",v);}

function saveHTML(){
  var b=new Blob([document.documentElement.outerHTML],{type:"text/html"});
  var a=document.createElement("a");
  a.href=URL.createObjectURL(b); a.download="MOTI_"+(S.dwgNo||"drawing")+".html";
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
}

// ============================================================
// INIT
// ============================================================
document.addEventListener("keydown",function(e){
  if(e.key==="Escape"&&wireStart){wireStart=null;updateRouteHint(null);renderCanvas();}
});

loadState();
syncCustomConnectors();

var th=localStorage.getItem("moti_theme")||"";
document.body.className=th;
var thSel=document.getElementById("th-sel");
if(thSel) thSel.value=th;

function syncTB(id,val){var el=document.getElementById(id);if(el)el.value=val||"";}
syncTB("tb-title",S.title); syncTB("tb-pn",S.partNo); syncTB("tb-dwg",S.dwgNo);
syncTB("tb-rev",S.rev); syncTB("tb-co",S.company); syncTB("tb-drawn",S.drawnBy);
syncTB("tb-len",S.cableLength); syncTB("tb-tol",S.lengthTol);

buildSidebar();
initCanvas();
renderAll();
setTool("select");


// ============================================================
// HARNESS VIEW — Physical Cable Layout Engine v2
// Looks like a real harness drawing (RapidHarness style)
// ============================================================

// ── State ──
// Nodes: connectors + junction points (draggable)
// Segs:  cable segments between nodes (trunk/branch)
// Each node has: {id, label, connId, x, y, isJunction, angle}
// Each seg has:  {id, from, to, lengthMm, label, wires[], pts[]}

// ============================================================
// HARNESS VIEW v3 — Engineering Drawing Engine
// Professional harness schematic à la RapidHarness / AIR style
// ============================================================


// ═══════════════════════════════════════════════════════════════
// HARNESS VIEW ENGINE
// Physical cable layout canvas — drag & drop topology editor
// ═══════════════════════════════════════════════════════════════