'use strict';

/* ============================================================
   CORE.JS — Layer 1: Data Model + Rules + Calculations
   MOTI HarnessPro v8
   ============================================================ */
'use strict';

/* ─────────────────────────────────────────────
   DATA MODEL
   Single source of truth for all outputs.
   Every output (wire list, drawing, BOM, nailboard)
   is derived from this state — never from UI state.
   ───────────────────────────────────────────── */

var S = {
  /* ── Project metadata ── */
  title:      '',
  partNo:     '',
  dwgNo:      '',
  rev:        'A',
  drawnBy:    '',
  approvedBy: '',
  company:    '',
  projectDate: '',

  /* ── Canvas elements ── */
  elements:   [],   /* Connector / Accessory objects */
  wires:      [],   /* Wire objects */
  dimensions: [],   /* Dimension annotations */
  labels:     [],   /* Text labels */

  /* ── Engineering data ── */
  bomItems:   [],   /* Manual BOM additions */
  notes:      [],   /* Drawing notes */

  /* ── Wire harness specs ── */
  cableLength: 500,  /* mm */
  lengthTol:   20,   /* mm +/- */
  stripFrom:   8,    /* mm — conductor A end */
  stripTo:     8,    /* mm — conductor B end */

  /* ── App state (non-engineering) ── */
  zoom:       1,
  panX:       80,
  panY:       80,
  canvasFontSize: 9,
  nextConnLabel:  1,
  customConnectors: [],
};

/* ─────────────────────────────────────────────
   WIRE OBJECT SCHEMA
   {
     id:         string   — unique
     wireNum:    string   — e.g. "1-P1-001" (auto or manual)
     fromEl:     string   — element id
     fromPin:    string   — pin id
     toEl:       string   — element id
     toPin:      string   — pin id
     signal:     string   — signal name e.g. "VCC", "CAN_H"
     gauge:      string   — AWG e.g. "22AWG"
     color:      string   — hex #rrggbb
     color2:     string   — hex for stripe (IEC combo)
     colorAbbr:  string   — IEC abbr e.g. "RD/WH"
     active:     bool
     routePts:   array    — [{x,y}] computed by autoroute
     routeStyle: string   — "ortho"|"curve"|"direct"
   }
   ───────────────────────────────────────────── */

/* ─────────────────────────────────────────────
   CONNECTOR ELEMENT SCHEMA
   {
     id:      string
     kind:    "connector"
     connId:  string   — key into CL library
     label:   string   — e.g. "P1"
     x, y:   number   — canvas world coords
     side:   string   — "left"|"right"
     notes:  string
   }
   ───────────────────────────────────────────── */

/* ─────────────────────────────────────────────
   HARNESS TOPOLOGY STATE
   Separate from S — built from S by hvBuildTopology()
   ───────────────────────────────────────────── */
var H = {
  nodes: [],   /* [{id, label, connId, x, y, angle, isJunction}] */
  segs:  [],   /* [{id, from, to, wires:[], lengthMm, label, pts:[]}] */
  zoom:  1,  panX: 120, panY: 150,
  sel:   null, drag: null,
};

/* ─────────────────────────────────────────────
   IEC 60757 WIRE COLOR STANDARD
   ───────────────────────────────────────────── */
var IEC_COLORS = [
  {code:0,  abbr:'BK', name:'Black',         hex:'#1a1a1a'},
  {code:1,  abbr:'BN', name:'Brown',         hex:'#7b3f00'},
  {code:2,  abbr:'RD', name:'Red',           hex:'#e74c3c'},
  {code:3,  abbr:'OG', name:'Orange',        hex:'#e67e22'},
  {code:4,  abbr:'YE', name:'Yellow',        hex:'#f1c40f'},
  {code:5,  abbr:'GN', name:'Green',         hex:'#27ae60'},
  {code:6,  abbr:'BU', name:'Blue',          hex:'#2980b9'},
  {code:7,  abbr:'VT', name:'Violet',        hex:'#8e44ad'},
  {code:8,  abbr:'GY', name:'Grey',          hex:'#95a5a6'},
  {code:9,  abbr:'WH', name:'White',         hex:'#e8e4dc'},
  {code:'PE',abbr:'GNYE',name:'Green/Yellow (Earth)', hex:'#27ae60', hex2:'#f1c40f'},
];
var IEC_COMBOS = [
  {abbr:'BK/WH',c1:'#1a1a1a',c2:'#e8e4dc'},{abbr:'BK/RD',c1:'#1a1a1a',c2:'#e74c3c'},
  {abbr:'BK/BU',c1:'#1a1a1a',c2:'#2980b9'},{abbr:'RD/WH',c1:'#e74c3c',c2:'#e8e4dc'},
  {abbr:'RD/BK',c1:'#e74c3c',c2:'#1a1a1a'},{abbr:'WH/BK',c1:'#e8e4dc',c2:'#1a1a1a'},
  {abbr:'WH/RD',c1:'#e8e4dc',c2:'#e74c3c'},{abbr:'WH/BU',c1:'#e8e4dc',c2:'#2980b9'},
  {abbr:'BU/WH',c1:'#2980b9',c2:'#e8e4dc'},{abbr:'GN/YE',c1:'#27ae60',c2:'#f1c40f'},
  {abbr:'BN/WH',c1:'#7b3f00',c2:'#e8e4dc'},{abbr:'OG/WH',c1:'#e67e22',c2:'#e8e4dc'},
  {abbr:'GY/WH',c1:'#95a5a6',c2:'#e8e4dc'},{abbr:'YE/GN',c1:'#f1c40f',c2:'#27ae60'},
];

function iecAbbr(hex, hex2) {
  if (hex2) {
    for (var i=0;i<IEC_COMBOS.length;i++)
      if (IEC_COMBOS[i].c1===hex && IEC_COMBOS[i].c2===hex2) return IEC_COMBOS[i].abbr;
    return 'CUST';
  }
  for (var j=0;j<IEC_COLORS.length;j++)
    if (IEC_COLORS[j].hex===hex) return IEC_COLORS[j].abbr;
  return 'CUST';
}

/* ─────────────────────────────────────────────
   CALCULATIONS
   Pure functions — no side effects.
   All outputs call these; they never touch DOM.
   ───────────────────────────────────────────── */
var CALC = {

  /* Cut length for a single wire */
  cutLength: function(cableLen, stripFrom, stripTo) {
    return (cableLen||0) + (stripFrom||0) + (stripTo||0);
  },

  /* AWG string → mm² cross-section */
  awgToMM2: function(awg) {
    var n = parseInt(awg);
    var t = {10:5.26,12:3.31,14:2.08,16:1.31,18:0.823,
             20:0.518,22:0.326,24:0.205,26:0.129,28:0.081,30:0.051};
    return t[n] || 0.326;
  },

  /* Bundle diameter from array of AWG strings, fill factor 0.55 */
  bundleDiameter: function(gaugeList) {
    var totalMM2 = 0;
    gaugeList.forEach(function(g){ totalMM2 += CALC.awgToMM2(g); });
    if (!totalMM2) return 0;
    return Math.round(Math.sqrt(totalMM2 / 0.55) * 20) / 10;
  },

  /* Returns true if wire gauge is thinner than pin allows */
  awgMismatch: function(wireGauge, pinSpec) {
    var w = parseInt(wireGauge), p = parseInt(pinSpec);
    return !isNaN(w) && !isNaN(p) && w > p + 2;
  },

  /* Build complete wire list — the master document for manufacturing */
  wireList: function() {
    var rows = [];
    S.wires.forEach(function(w) {
      if (!w.active && w.active !== undefined) return;
      var fromEl = null, toEl = null;
      S.elements.forEach(function(e){
        if (e.id === w.fromEl) fromEl = e;
        if (e.id === w.toEl)   toEl   = e;
      });
      var fromLib = fromEl ? CL[fromEl.connId] : null;
      var toLib   = toEl   ? CL[toEl.connId]   : null;
      var fromPinName = '', toPinName = '', fromPinSpec = '', toPinSpec = '';
      if (fromLib) fromLib.pinout.forEach(function(p){
        if (String(p.id)===String(w.fromPin)) { fromPinName=p.n; fromPinSpec=p.g||''; }
      });
      if (toLib) toLib.pinout.forEach(function(p){
        if (String(p.id)===String(w.toPin))   { toPinName=p.n;   toPinSpec=p.g||''; }
      });
      rows.push({
        wireNum:      w.wireNum || '',
        fromLabel:    fromEl ? (fromEl.label||'?') : '?',
        fromPin:      w.fromPin || '',
        fromPinName:  fromPinName,
        toLabel:      toEl   ? (toEl.label||'?')   : '?',
        toPin:        w.toPin || '',
        toPinName:    toPinName,
        signal:       w.signal || '',
        gauge:        w.gauge  || '',
        color:        w.color  || '',
        color2:       w.color2 || '',
        colorAbbr:    w.colorAbbr || iecAbbr(w.color||'',w.color2||null),
        cableLen:     S.cableLength,
        stripFrom:    S.stripFrom,
        stripTo:      S.stripTo,
        cutLength:    CALC.cutLength(S.cableLength, S.stripFrom, S.stripTo),
        fromPinSpec:  fromPinSpec,
        toPinSpec:    toPinSpec,
        awgOK:        !fromPinSpec || !CALC.awgMismatch(w.gauge||'', fromPinSpec),
      });
    });
    /* Sort by wire number */
    rows.sort(function(a,b){ return a.wireNum.localeCompare(b.wireNum); });
    return rows;
  },

  /* Build BOM — connectors from canvas + manual items, deduplicated */
  bom: function() {
    var items = [];
    var seen  = {};
    /* Connectors from canvas */
    S.elements.forEach(function(el) {
      if (el.kind !== 'connector') return;
      var lib = CL[el.connId]; if (!lib) return;
      var key = lib.pn || lib.id;
      if (seen[key]) { seen[key].qty++; return; }
      seen[key] = {
        pn:   lib.pn || lib.id,
        desc: lib.name,
        cat:  'CONNECTOR',
        qty:  1,
        unit: 'EA',
        std:  lib.std || '',
      };
      items.push(seen[key]);
    });
    /* Wire materials — group by gauge+color */
    var wireMap = {};
    S.wires.forEach(function(w) {
      var key = (w.gauge||'22AWG') + '_' + (w.colorAbbr||w.color||'');
      if (!wireMap[key]) wireMap[key] = {gauge: w.gauge||'22AWG', abbr: w.colorAbbr||w.color||'', count:0};
      wireMap[key].count++;
    });
    Object.keys(wireMap).forEach(function(k) {
      var wm = wireMap[k];
      var lenM = Math.ceil(CALC.cutLength(S.cableLength, S.stripFrom, S.stripTo) * wm.count / 1000 * 1.15 * 10) / 10;
      items.push({pn:'', desc:'Wire '+wm.gauge+' '+wm.abbr+' x'+wm.count, cat:'WIRE', qty:lenM, unit:'M', std:''});
    });
    /* Manual BOM items */
    S.bomItems.forEach(function(it) {
      items.push({pn:it.pn||'', desc:it.desc||'', cat:it.cat||'PURCHASED', qty:it.qty||1, unit:it.unit||'EA', std:''});
    });
    return items;
  },
};

/* ─────────────────────────────────────────────
   LVS — Layout vs Schematic
   Runs on every renderAll(). Shows results in
   the LVS panel strip below the toolbar.
   ───────────────────────────────────────────── */
function runLVS() {
  var errors = [], warnings = [];
  var connEls = S.elements.filter(function(e){ return e.kind==='connector'; });

  connEls.forEach(function(el) {
    var lib = CL[el.connId]; if (!lib) return;
    lib.pinout.forEach(function(pp) {
      if (pp.n==='NC' || pp.sig==='NC') return;
      var conn = S.wires.some(function(w) {
        return (w.fromEl===el.id && String(w.fromPin)===String(pp.id)) ||
               (w.toEl  ===el.id && String(w.toPin)  ===String(pp.id));
      });
      if (!conn) warnings.push((el.label||el.id)+'.'+pp.id+' ('+pp.n+') unconnected');
    });
  });

  S.wires.forEach(function(w) {
    if (!w.fromEl || !w.toEl) { errors.push('Floating wire '+(w.wireNum||w.id)); return; }
    if (w.fromEl===w.toEl)    { errors.push('Self-loop: '+(w.signal||w.id)); return; }
    /* AWG check */
    S.elements.forEach(function(el) {
      if (el.id !== w.fromEl) return;
      var lib=CL[el.connId]; if(!lib) return;
      lib.pinout.forEach(function(p) {
        if (String(p.id)===String(w.fromPin) && p.g && CALC.awgMismatch(w.gauge||'',p.g))
          warnings.push('AWG: '+(el.label||'?')+'.'+p.id+' spec='+p.g+' got='+w.gauge);
      });
    });
  });

  /* Duplicate wire numbers */
  var nums={};
  S.wires.forEach(function(w) {
    if (!w.wireNum) return;
    if (nums[w.wireNum]) errors.push('Dup wire# '+w.wireNum);
    nums[w.wireNum]=true;
  });

  var panel = document.getElementById('lvs-panel');
  if (!panel) return;
  if (!errors.length && !warnings.length) {
    panel.innerHTML='<span style="color:#27ae60;padding:0 8px;font-size:8px;font-weight:bold">&#10003; LVS PASS — '+connEls.length+' connectors, '+S.wires.length+' wires</span>';
    return;
  }
  var h='';
  errors.forEach(function(e)  { h+='<span style="color:#e74c3c;padding:0 8px;font-size:8px">&#9679; ERR: '+esc(e)+'</span> '; });
  warnings.forEach(function(w){ h+='<span style="color:#f39c12;padding:0 8px;font-size:8px">&#9651; '+esc(w)+'</span> '; });
  panel.innerHTML=h;
}

/* ─────────────────────────────────────────────
   WIRE NUMBERING
   ───────────────────────────────────────────── */
function wireAutoNumber() {
  var connEls = S.elements.filter(function(e){return e.kind==='connector';});
  var counter = {};
  S.wires.forEach(function(w) {
    if (w.wireNum) return;
    var label='X';
    connEls.forEach(function(e){ if(e.id===w.fromEl) label=e.label||'X'; });
    counter[label] = (counter[label]||0) + 1;
    w.wireNum = '1-'+label+'-'+String(counter[label]).padStart(3,'0');
  });
  saveState(); renderRoutes(); renderCanvas();
  toast('Wire numbers assigned');
}

/* ─────────────────────────────────────────────
   UNDO / REDO
   ───────────────────────────────────────────── */
var _US=[], _RS=[], _UL=false;

function _snap() {
  return JSON.stringify({
    el:S.elements, wi:S.wires, di:S.dimensions, la:S.labels||[], bo:S.bomItems
  });
}
function _rest(d) {
  var p=JSON.parse(d);
  S.elements=p.el; S.wires=p.wi; S.dimensions=p.di;
  S.labels=p.la||[]; S.bomItems=p.bo||[];
}
function pushUndo() {
  if(_UL)return; _US.push(_snap()); if(_US.length>80)_US.shift(); _RS=[]; _udUI();
}
function undoAction() {
  if(!_US.length)return; _RS.push(_snap()); _UL=true; _rest(_US.pop()); _UL=false;
  saveState(); renderAll(); _udUI(); toast('Undo');
}
function redoAction() {
  if(!_RS.length)return; _US.push(_snap()); _UL=true; _rest(_RS.pop()); _UL=false;
  saveState(); renderAll(); _udUI(); toast('Redo');
}
function _udUI() {
  var u=document.getElementById('btn-undo'), r=document.getElementById('btn-redo');
  if(u) u.style.opacity=_US.length?'1':'0.35';
  if(r) r.style.opacity=_RS.length?'1':'0.35';
}

/* ─────────────────────────────────────────────
   PERSISTENCE
   ───────────────────────────────────────────── */
var _KEY='moti_hp_v8';

function saveState() {
  try { localStorage.setItem(_KEY, JSON.stringify({s:S,hn:H.nodes,hs:H.segs})); }
  catch(e){}
}
function loadState() {
  try {
    var raw=localStorage.getItem(_KEY); if(!raw)return;
    var d=JSON.parse(raw);
    if(d.s){ for(var k in d.s) if(d.s.hasOwnProperty(k)) S[k]=d.s[k]; }
    if(d.hn) H.nodes=d.hn;
    if(d.hs) H.segs=d.hs;
  } catch(e){}
}
function newProject() {
  if(!confirm('New project? Unsaved changes will be lost.'))return;
  S.elements=[]; S.wires=[]; S.dimensions=[]; S.labels=[]; S.bomItems=[];
  S.title=''; S.partNo=''; S.dwgNo=''; S.rev='A'; S.drawnBy='';
  S.approvedBy=''; S.company=''; S.notes=[]; S.nextConnLabel=1;
  S.cableLength=500; S.lengthTol=20; S.stripFrom=8; S.stripTo=8;
  H.nodes=[]; H.segs=[];
  _US=[]; _RS=[];
  saveState(); syncCustomConnectors(); buildSidebar(); renderAll(); syncTBAll(); _udUI();
  toast('New project');
}

/* ─────────────────────────────────────────────
   UTILITIES (used across all layers)
   ───────────────────────────────────────────── */
function uid() { return Math.random().toString(36).slice(2,9)+Date.now().toString(36).slice(-4); }
function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function sc(c) { return (c&&(c[0]==='#'||c.indexOf('hsl')===0))?c:'#888888'; }
function clamp(v,mn,mx){ return Math.max(mn,Math.min(mx,v)); }

function toast(msg,isErr){
  var el=document.getElementById('toast'); if(!el)return;
  el.textContent=msg;
  el.style.background=isErr?'#3a0808':'#0a2010';
  el.style.color=isErr?'#e74c3c':'#5ab04a';
  el.style.display='block';
  clearTimeout(toast._t);
  toast._t=setTimeout(function(){el.style.display='none';},2800);
}

function mkpins(n,pre,sig,awg,hStep){
  var r=[]; for(var i=0;i<n;i++){
    var h=(i*(hStep||30))%360;
    r.push({id:i+1,n:pre+(i+1),sig:sig,g:awg,c:'hsl('+h+',65%,52%)'});
  } return r;
}

function syncCustomConnectors(){
  for(var k in CL){if(!CL[k].builtin)delete CL[k];}
  (S.customConnectors||[]).forEach(function(cc){cc.builtin=false;CL[cc.id]=cc;});
}

function syncTB(id,val){ var el=document.getElementById(id); if(el&&el.value!==undefined)el.value=val||''; }
function syncTBAll(){
  syncTB('tb-title',S.title); syncTB('tb-pn',S.partNo); syncTB('tb-dwg',S.dwgNo);
  syncTB('tb-rev',S.rev); syncTB('tb-co',S.company); syncTB('tb-drawn',S.drawnBy);
  syncTB('tb-len',S.cableLength); syncTB('tb-tol',S.lengthTol);
}

function renderAll(){
  saveState();
  if(typeof renderDrawing==='function')  renderDrawing();
  if(typeof renderRoutes==='function')   renderRoutes();
  if(typeof renderBOM==='function')      renderBOM();
  if(typeof renderCutList==='function')  renderCutList();
  if(typeof renderCanvas==='function')   renderCanvas();
  setTimeout(runLVS,200);
}
