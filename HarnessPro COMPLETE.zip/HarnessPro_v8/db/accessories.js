'use strict';


var ACCESSORIES = [
  {id:"HS-3",  name:"Heat Shrink 3mm",   type:"heatshrink", color:"#222", symbol:"HS"},
  {id:"HS-6",  name:"Heat Shrink 6mm",   type:"heatshrink", color:"#222", symbol:"HS"},
  {id:"HS-10", name:"Heat Shrink 10mm",  type:"heatshrink", color:"#555", symbol:"HS"},
  {id:"SP-5",  name:"Split Loom 5mm",    type:"sleeve",     color:"#1a3a1a", symbol:"SP"},
  {id:"SP-10", name:"Split Loom 10mm",   type:"sleeve",     color:"#1a3a1a", symbol:"SP"},
  {id:"BR-BL", name:"Braided Sleeve Black",type:"sleeve",   color:"#111", symbol:"BR"},
  {id:"TM-W",  name:"Wire Marker White", type:"marker",     color:"#eee", symbol:"M"},
  {id:"TM-Y",  name:"Wire Marker Yellow",type:"marker",     color:"#f39c12", symbol:"M"},
  {id:"FR-F",  name:"Ferrule 0.5mm",     type:"terminal",   color:"#e74c3c", symbol:"T"},
  {id:"FR-1",  name:"Ferrule 1.0mm",     type:"terminal",   color:"#3498db", symbol:"T"},
  {id:"FR-2",  name:"Ferrule 2.5mm",     type:"terminal",   color:"#27ae60", symbol:"T"},
  {id:"TIE",   name:"Cable Tie",         type:"cable_tie",  color:"#eee", symbol:"Z"}
];
